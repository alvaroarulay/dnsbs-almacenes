<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Entradas;
use App\Models\Personal;
use Barryvdh\Snappy\Facades\SnappyPdf as PDF;
use App\Models\Almacenes;
use App\Models\Establecimiento;
use Jenssegers\Date\Date;

class EntradasController extends Controller
{
    public function index(Request $request)
    {
        $buscar = $request->buscar;
        $criterio = $request->criterio;
        $query = Entradas::join('articulos', 'entradas.id_articulo', '=', 'articulos.id')
            ->join('personal', 'entradas.id_personal', '=', 'personal.id')
            ->join('provedores', 'entradas.id_proveedor', '=', 'provedores.id')
            ->select('entradas.*', 'articulos.codigo','articulos.descripcion' , 'personal.nomper as personal', 'provedores.nompro as proveedor');
        if ($buscar=='') {
            $entradas = $query->paginate(10);
        } else {
            $entradas = $query->where('articulos.'.$criterio, 'like', '%' . $buscar . '%')->paginate(10);
        }
        return [
            'pagination' => [
                'total'         => $entradas->total(),
                'current_page'  => $entradas->currentPage(),
                'per_page'      => $entradas->perPage(),
                'last_page'     => $entradas->lastPage(),
                'from'          => $entradas->firstItem(),
                'to'            => $entradas->lastItem(),
            ],
            'entradas' => $entradas
        ];

    }
    public function store(Request $request)
    {
        try{
            foreach ($request->arrayCompras as $compra) {
                $entrada = new Entradas();
                $entrada->fecha = now();
                $entrada->cantidad = $compra['cantidad'];
                $entrada->precio_unitario = $compra['precio'];
                $entrada->restante = $compra['cantidad'];
                $entrada->id_articulo = $compra['idarticulo'];
                $entrada->id_personal = $request->idpersonal;
                $entrada->id_proveedor = $request->idprovedor;
                $entrada->save();
            }
             return response()->json(['message' => 'Datos Guardados!']);
        }catch(\Exception $e){
            return response()->json(['error' => 'Error al registrar la entrada: ' . $e->getMessage()], 500);
        }
    }
    public function pdfEntradas(){
        Date::setLocale('es');
        $fechaTitulo = Date::now()->format('l j F Y');
        $fechDerecha = Date::now()->format('d/M/Y');
        $datos = Entradas::join('articulos', 'entradas.id_articulo', '=', 'articulos.id')
            ->join('personal', 'entradas.id_personal', '=', 'personal.id')
            ->join('provedores', 'entradas.id_proveedor', '=', 'provedores.id')
            ->select('entradas.*', 'articulos.codigo','articulos.descripcion' , 'personal.nomper as personal', 'provedores.nompro as proveedor')
            ->orderBy('entradas.id', 'asc')->get();
        $titulo = 'Listado de Compras';
        $almacen = Almacenes::find(1);
        $establecimiento = Establecimiento::find(1);
        $html = view('plantillapdf.mainentradas', [ 'datos' => $datos, 'almacen' => $almacen->nomalmacen, 'establecimiento' => $establecimiento->nomestab ])->render();
        $headerHtml = view('plantillapdf.header', [
            'fechaTitulo' => $fechaTitulo,
            'titulo' => $titulo,
            'fechaDerecha' => $fechDerecha,
        ])->render();
        $footerhtml = view('plantillapdf.footer')->render();

        return Pdf::loadHTML($html)
            ->setOption('header-html', $headerHtml)
            ->setOption('footer-html', $footerhtml)
            ->setOption('margin-top', '40mm') // espacio para el header
            ->setOption('margin-bottom', '20mm') // espacio para el footer
            ->setOption('header-spacing', 5)  // espacio entre header y contenido
            ->setPaper('letter', 'portrait') // tamaño de papel y orientación
            ->setOption('footer-right', 'Página: [page] de [topage]')
            ->setOption('footer-font-size', 8)
            ->inline('documento.pdf');
        }
}
