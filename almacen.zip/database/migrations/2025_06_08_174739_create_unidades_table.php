<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('unidades', function (Blueprint $table) {
            $table->id();
            $table->string('nomunidad')->unique();
            $table->string('sigla')->nullable();
            $table->timestamps();
        });
        DB::table('unidades')->insert(array('id'=>1,'nomunidad'=>'AMARRO','sigla'=>'AMR'));
        DB::table('unidades')->insert(array('id'=>2,'nomunidad'=>'AMPOLLA','sigla'=>'AM'));
        DB::table('unidades')->insert(array('id'=>3,'nomunidad'=>'ARROBA','sigla'=>'ARR'));
        DB::table('unidades')->insert(array('id'=>4,'nomunidad'=>'BARRA','sigla'=>'BAR'));
        DB::table('unidades')->insert(array('id'=>5,'nomunidad'=>'BIDON','sigla'=>'BID'));
        DB::table('unidades')->insert(array('id'=>6,'nomunidad'=>'BLOCK','sigla'=>'BLC'));
        DB::table('unidades')->insert(array('id'=>7,'nomunidad'=>'BOLSA','sigla'=>'BL'));
        DB::table('unidades')->insert(array('id'=>8,'nomunidad'=>'BOLSITA','sigla'=>'BOL'));
        DB::table('unidades')->insert(array('id'=>9,'nomunidad'=>'BOTELLA','sigla'=>'BOT'));
        DB::table('unidades')->insert(array('id'=>10,'nomunidad'=>'CAJA','sigla'=>'BX'));
        DB::table('unidades')->insert(array('id'=>11,'nomunidad'=>'CARGA','sigla'=>'CRG'));
        DB::table('unidades')->insert(array('id'=>12,'nomunidad'=>'CILINDRO','sigla'=>'CY'));
        DB::table('unidades')->insert(array('id'=>13,'nomunidad'=>'CUARTILLA','sigla'=>'CRT'));
        DB::table('unidades')->insert(array('id'=>14,'nomunidad'=>'DOCENA','sigla'=>'DZN'));
        DB::table('unidades')->insert(array('id'=>15,'nomunidad'=>'FRACOS','sigla'=>'FRA'));
        DB::table('unidades')->insert(array('id'=>16,'nomunidad'=>'FRASCO','sigla'=>'FR'));
        DB::table('unidades')->insert(array('id'=>17,'nomunidad'=>'GALON','sigla'=>'GAL'));
        DB::table('unidades')->insert(array('id'=>18,'nomunidad'=>'GARRAFA','sigla'=>'GAR'));
        DB::table('unidades')->insert(array('id'=>19,'nomunidad'=>'HOJA','sigla'=>'HOJ'));
        DB::table('unidades')->insert(array('id'=>20,'nomunidad'=>'HOJAS','sigla'=>'HOJ'));
        DB::table('unidades')->insert(array('id'=>21,'nomunidad'=>'JUEGO','sigla'=>'SET'));
        DB::table('unidades')->insert(array('id'=>22,'nomunidad'=>'JUEGOS','sigla'=>'SET'));
        DB::table('unidades')->insert(array('id'=>23,'nomunidad'=>'KILO','sigla'=>'KIL'));
        DB::table('unidades')->insert(array('id'=>24,'nomunidad'=>'KIT','sigla'=>'KT'));
        DB::table('unidades')->insert(array('id'=>25,'nomunidad'=>'LITRO','sigla'=>'LTR'));
        DB::table('unidades')->insert(array('id'=>26,'nomunidad'=>'METRO','sigla'=>'MTR'));
        DB::table('unidades')->insert(array('id'=>27,'nomunidad'=>'MONTON','sigla'=>'MON'));
        DB::table('unidades')->insert(array('id'=>28,'nomunidad'=>'P.H.','sigla'=>'PH'));
        DB::table('unidades')->insert(array('id'=>29,'nomunidad'=>'PAQUETE','sigla'=>'PK'));
        DB::table('unidades')->insert(array('id'=>30,'nomunidad'=>'PAR','sigla'=>'PR'));
        DB::table('unidades')->insert(array('id'=>31,'nomunidad'=>'PIEZA','sigla'=>'PZA'));
        DB::table('unidades')->insert(array('id'=>32,'nomunidad'=>'PIEZAS','sigla'=>'PZA'));
        DB::table('unidades')->insert(array('id'=>33,'nomunidad'=>'PLIEGO','sigla'=>'ST'));
        DB::table('unidades')->insert(array('id'=>34,'nomunidad'=>'QUINTAL','sigla'=>'QQ'));
        DB::table('unidades')->insert(array('id'=>35,'nomunidad'=>'ROLLO','sigla'=>'RO'));
        DB::table('unidades')->insert(array('id'=>36,'nomunidad'=>'SACHET','sigla'=>'SA'));
        DB::table('unidades')->insert(array('id'=>37,'nomunidad'=>'SET','sigla'=>'SET'));
        DB::table('unidades')->insert(array('id'=>38,'nomunidad'=>'UNIDAD','sigla'=>'UNI'));
        DB::table('unidades')->insert(array('id'=>39,'nomunidad'=>'UNIDADES','sigla'=>'UNI'));
        DB::table('unidades')->insert(array('id'=>40,'nomunidad'=>'VARIOS','sigla'=>'VAR'));

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('unidades');
    }
};
