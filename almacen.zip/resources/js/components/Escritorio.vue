<template>
    <main class="app-content">
        <div class="app-title">
          <h1><i class="bi bi-speedometer"></i> Escritorio</h1>
          <p>Progreso de Inventario</p>
        </div>
       <div class="row">
          <div class="col-md-3">
            <div class="card widget-small primary coloured-icon" style="width: 25rem">
              <div class="card-body">
                <div class="row">
                  <div class="col-md-6">
                    <i class="icon bi bi-receipt" style="font-size: 4rem;"></i>
                  </div>
                  <div class="col-md-6 text-center">
                    <h2 class="card-title" style="font-size:3em;">852</h2>
                    <div class="mt-2 lead">Productos</div>
                  </div>
                </div>
                <hr>
                <div class="row">
                  <div class="col-md-6">
                    <p class="text-white">
                      <span class="ms-2 text-muted">Ver más</span>
                    </p>
                  </div>
                  <div class="col-md-6 text-end">
                    <a href="" target="_blank" rel="noopener noreferrer"> <i class="bi bi-arrow-right-circle" style="font-size: 1.5rem;"></i></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card widget-small info coloured-icon" style="width: 25rem">
              <div class="card-body">
                <div class="row">
                  <div class="col-md-6">
                    <i class="icon bi bi-cart" style="font-size: 4rem;"></i>
                  </div>
                  <div class="col-md-6 text-center">
                    <h2 class="card-title" style="font-size:3em;">52</h2>
                    <div class="mt-2 lead">Salidas</div>
                  </div>
                </div>
                <hr>
                <div class="row">
                  <div class="col-md-6">
                    <p class="text-white">
                      <span class="ms-2 text-muted">Nueva Salida</span>
                    </p>
                  </div>
                  <div class="col-md-6 text-end">
                    <a href="" target="_blank" rel="noopener noreferrer"> <i class="bi bi-arrow-right-circle" style="font-size: 1.5rem;"></i></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card widget-small warning coloured-icon" style="width: 25rem">
              <div class="card-body">
                <div class="row">
                  <div class="col-md-6">
                    <i class="icon bi bi-truck" style="font-size: 4rem;"></i>
                  </div>
                  <div class="col-md-6 text-center">
                    <h2 class="card-title" style="font-size:3em;">63</h2>
                    <div class="mt-2 lead">Entradas</div>
                  </div>
                </div>
                <hr>
                <div class="row">
                  <div class="col-md-6">
                    <p class="text-white">
                      <span class="ms-2 text-muted">Nueva Entrada</span>
                    </p>
                  </div>
                  <div class="col-md-6 text-end">
                    <a href="" target="_blank" rel="noopener noreferrer"> <i class="bi bi-arrow-right-circle" style="font-size: 1.5rem;"></i></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card widget-small danger coloured-icon" style="width: 25rem">
              <div class="card-body">
                <div class="row">
                  <div class="col-md-6">
                    <i class="icon bi bi-bar-chart" style="font-size: 4rem;"></i>
                  </div>
                  <div class="col-md-6 text-center">
                    <i class="bi bi-pen" style="font-size: 2rem;"></i>
                    <div class="mt-2 lead">Reportes</div>
                  </div>
                </div>
                <hr>
                <div class="row">
                  <div class="col-md-6">
                    <p class="text-white">
                      <span class="ms-2 text-muted">Ver más</span>
                    </p>
                  </div>
                  <div class="col-md-6 text-end">
                    <a href="" target="_blank" rel="noopener noreferrer"> <i class="bi bi-arrow-right-circle" style="font-size: 1.5rem;"></i></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
       </div>
       <div class="row">
          <div class="col-md-3">
            <div class="card widget-small warning coloured-icon" style="width: 25rem; ">
              <div class="card-body">
                <div class="row">
                  <div class="col-md-6">
                    <i class="icon bi bi-person" style="font-size: 4rem;"></i>
                  </div>
                  <div class="col-md-6 text-center">
                    <h2 class="card-title" style="font-size:3em;">63</h2>
                    <div class="mt-2 lead">Personal</div>
                  </div>
                </div>
                <hr>
                <div class="row">
                  <div class="col-md-6">
                    <p>
                      <span class="ms-2 text-muted">Ver más</span>
                    </p>
                  </div>
                  <div class="col-md-6 text-end">
                    <a href="" target="_blank" rel="noopener noreferrer"> <i class="bi bi-arrow-right-circle" style="font-size: 1.5rem;"></i></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card widget-small danger coloured-icon" style="width: 25rem; ">
              <div class="card-body">
                <div class="row">
                  <div class="col-md-6">
                    <i class="icon bi bi-bag" style="font-size: 4rem;"></i>
                  </div>
                  <div class="col-md-6 text-center">
                    <h2 class="card-title" style="font-size:3em;">63</h2>
                    <div class="mt-2 lead">Provedores</div>
                  </div>
                </div>
                <hr>
                <div class="row">
                  <div class="col-md-6">
                    <p>
                      <span class="ms-2 text-muted">Ver más</span>
                    </p>
                  </div>
                  <div class="col-md-6 text-end">
                    <a href="" target="_blank" rel="noopener noreferrer"> <i class="bi bi-arrow-right-circle" style="font-size: 1.5rem;"></i></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card widget-small info coloured-icon" style="width: 25rem; ">
              <div class="card-body">
                <div class="row">
                  <div class="col-md-6">
                    <i class="icon bi bi-people-fill" style="font-size: 4rem;"></i>
                  </div>
                  <div class="col-md-6 text-center">
                    <h2 class="card-title" style="font-size:3em;">63</h2>
                    <div class="mt-2 lead">Usuarios</div>
                  </div>
                </div>
                <hr>
                <div class="row">
                  <div class="col-md-6">
                    <p>
                      <span class="ms-2 text-muted">Ver más</span>
                    </p>
                  </div>
                  <div class="col-md-6 text-end">
                    <a href="" target="_blank" rel="noopener noreferrer"> <i class="bi bi-arrow-right-circle" style="font-size: 1.5rem;"></i></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card widget-small primary coloured-icon" style="width: 25rem; ">
              <div class="card-body">
                <div class="row">
                  <div class="col-md-6">
                    <i class="icon bi bi-database" style="font-size: 4rem;"></i>
                  </div>
                  <div class="col-md-6 text-center">
                    <i class="bi bi-gear" style="font-size: 2rem;"></i>
                    <div class="mt-2 lead">Respaldos</div>
                  </div>
                </div>
                <hr>
                <div class="row">
                  <div class="col-md-6">
                    <p>
                      <span class="ms-2 text-muted">Configuración del Sistema</span>
                    </p>
                  </div>
                  <div class="col-md-6 text-end">
                       <a href="#" >
                          <i class="bi bi-arrow-right-circle" style="font-size: 1.5rem;"></i>
                        </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
       </div>
    </main>
   
</template>
