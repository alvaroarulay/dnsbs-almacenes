import { __VLS_internalComponent, __VLS_componentsOption, __VLS_name } from './Articulo.vue';

function __VLS_template() {
let __VLS_ctx!: InstanceType<__VLS_PickNotAny<typeof __VLS_internalComponent, new () => {}>> & {};
/* Components */
let __VLS_otherComponents!: NonNullable<typeof __VLS_internalComponent extends { components: infer C; } ? C : {}> & typeof __VLS_componentsOption;
let __VLS_own!: __VLS_SelfComponent<typeof __VLS_name, typeof __VLS_internalComponent & (new () => { $slots: typeof __VLS_slots; })>;
let __VLS_localComponents!: typeof __VLS_otherComponents & Omit<typeof __VLS_own, keyof typeof __VLS_otherComponents>;
let __VLS_components!: typeof __VLS_localComponents & __VLS_GlobalComponents & typeof __VLS_ctx;
/* Style Scoped */
type __VLS_StyleScopedClasses = {};
let __VLS_styleScopedClasses!: __VLS_StyleScopedClasses | keyof __VLS_StyleScopedClasses | (keyof __VLS_StyleScopedClasses)[];
/* CSS variable injection */
/* CSS variable injection end */
let __VLS_resolvedLocalAndGlobalComponents!: {} &
__VLS_WithComponent<'barcode', typeof __VLS_localComponents, "Barcode", "barcode", "barcode">;
__VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div; __VLS_intrinsicElements.div;
__VLS_intrinsicElements.h1; __VLS_intrinsicElements.h1;
__VLS_intrinsicElements.i; __VLS_intrinsicElements.i; __VLS_intrinsicElements.i; __VLS_intrinsicElements.i; __VLS_intrinsicElements.i; __VLS_intrinsicElements.i; __VLS_intrinsicElements.i; __VLS_intrinsicElements.i; __VLS_intrinsicElements.i; __VLS_intrinsicElements.i; __VLS_intrinsicElements.i; __VLS_intrinsicElements.i; __VLS_intrinsicElements.i; __VLS_intrinsicElements.i;
__VLS_intrinsicElements.br;
__VLS_intrinsicElements.button; __VLS_intrinsicElements.button; __VLS_intrinsicElements.button; __VLS_intrinsicElements.button; __VLS_intrinsicElements.button; __VLS_intrinsicElements.button; __VLS_intrinsicElements.button; __VLS_intrinsicElements.button; __VLS_intrinsicElements.button; __VLS_intrinsicElements.button; __VLS_intrinsicElements.button; __VLS_intrinsicElements.button; __VLS_intrinsicElements.button; __VLS_intrinsicElements.button; __VLS_intrinsicElements.button; __VLS_intrinsicElements.button; __VLS_intrinsicElements.button; __VLS_intrinsicElements.button; __VLS_intrinsicElements.button; __VLS_intrinsicElements.button;
__VLS_intrinsicElements.select; __VLS_intrinsicElements.select; __VLS_intrinsicElements.select; __VLS_intrinsicElements.select;
__VLS_intrinsicElements.option; __VLS_intrinsicElements.option; __VLS_intrinsicElements.option; __VLS_intrinsicElements.option; __VLS_intrinsicElements.option; __VLS_intrinsicElements.option; __VLS_intrinsicElements.option; __VLS_intrinsicElements.option;
__VLS_intrinsicElements.input; __VLS_intrinsicElements.input; __VLS_intrinsicElements.input; __VLS_intrinsicElements.input; __VLS_intrinsicElements.input; __VLS_intrinsicElements.input;
__VLS_intrinsicElements.table; __VLS_intrinsicElements.table;
__VLS_intrinsicElements.thead; __VLS_intrinsicElements.thead;
__VLS_intrinsicElements.tr; __VLS_intrinsicElements.tr; __VLS_intrinsicElements.tr; __VLS_intrinsicElements.tr;
__VLS_intrinsicElements.th; __VLS_intrinsicElements.th; __VLS_intrinsicElements.th; __VLS_intrinsicElements.th; __VLS_intrinsicElements.th; __VLS_intrinsicElements.th; __VLS_intrinsicElements.th; __VLS_intrinsicElements.th; __VLS_intrinsicElements.th; __VLS_intrinsicElements.th; __VLS_intrinsicElements.th; __VLS_intrinsicElements.th; __VLS_intrinsicElements.th; __VLS_intrinsicElements.th; __VLS_intrinsicElements.th; __VLS_intrinsicElements.th; __VLS_intrinsicElements.th; __VLS_intrinsicElements.th; __VLS_intrinsicElements.th; __VLS_intrinsicElements.th;
__VLS_intrinsicElements.tbody; __VLS_intrinsicElements.tbody;
__VLS_intrinsicElements.td; __VLS_intrinsicElements.td; __VLS_intrinsicElements.td; __VLS_intrinsicElements.td; __VLS_intrinsicElements.td; __VLS_intrinsicElements.td; __VLS_intrinsicElements.td; __VLS_intrinsicElements.td; __VLS_intrinsicElements.td; __VLS_intrinsicElements.td; __VLS_intrinsicElements.td; __VLS_intrinsicElements.td; __VLS_intrinsicElements.td; __VLS_intrinsicElements.td; __VLS_intrinsicElements.td; __VLS_intrinsicElements.td; __VLS_intrinsicElements.td; __VLS_intrinsicElements.td; __VLS_intrinsicElements.td; __VLS_intrinsicElements.td;
__VLS_intrinsicElements.span; __VLS_intrinsicElements.span; __VLS_intrinsicElements.span; __VLS_intrinsicElements.span; __VLS_intrinsicElements.span; __VLS_intrinsicElements.span;
__VLS_intrinsicElements.nav; __VLS_intrinsicElements.nav;
__VLS_intrinsicElements.ul; __VLS_intrinsicElements.ul;
__VLS_intrinsicElements.li; __VLS_intrinsicElements.li; __VLS_intrinsicElements.li; __VLS_intrinsicElements.li; __VLS_intrinsicElements.li; __VLS_intrinsicElements.li;
__VLS_intrinsicElements.a; __VLS_intrinsicElements.a; __VLS_intrinsicElements.a; __VLS_intrinsicElements.a; __VLS_intrinsicElements.a; __VLS_intrinsicElements.a;
__VLS_intrinsicElements.h4; __VLS_intrinsicElements.h4;
__VLS_intrinsicElements.form; __VLS_intrinsicElements.form;
__VLS_intrinsicElements.label; __VLS_intrinsicElements.label; __VLS_intrinsicElements.label; __VLS_intrinsicElements.label; __VLS_intrinsicElements.label; __VLS_intrinsicElements.label; __VLS_intrinsicElements.label; __VLS_intrinsicElements.label; __VLS_intrinsicElements.label; __VLS_intrinsicElements.label; __VLS_intrinsicElements.label; __VLS_intrinsicElements.label;
__VLS_components.Barcode; __VLS_components.Barcode; __VLS_components.barcode; __VLS_components.barcode;
// @ts-ignore
[barcode, barcode,];
{
const __VLS_0 = __VLS_intrinsicElements["div"];
const __VLS_1 = __VLS_elementAsFunctionalComponent(__VLS_0);
const __VLS_2 = __VLS_1({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_1));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_0, typeof __VLS_2> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_3 = __VLS_pickFunctionalComponentCtx(__VLS_0, __VLS_2)!;
let __VLS_4!: __VLS_NormalizeEmits<typeof __VLS_3.emit>;
{
const __VLS_5 = __VLS_intrinsicElements["div"];
const __VLS_6 = __VLS_elementAsFunctionalComponent(__VLS_5);
const __VLS_7 = __VLS_6({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_6));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_5, typeof __VLS_7> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_8 = __VLS_pickFunctionalComponentCtx(__VLS_5, __VLS_7)!;
let __VLS_9!: __VLS_NormalizeEmits<typeof __VLS_8.emit>;
{
const __VLS_10 = __VLS_intrinsicElements["h1"];
const __VLS_11 = __VLS_elementAsFunctionalComponent(__VLS_10);
const __VLS_12 = __VLS_11({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_11));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_10, typeof __VLS_12> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_13 = __VLS_pickFunctionalComponentCtx(__VLS_10, __VLS_12)!;
let __VLS_14!: __VLS_NormalizeEmits<typeof __VLS_13.emit>;
{
const __VLS_15 = __VLS_intrinsicElements["i"];
const __VLS_16 = __VLS_elementAsFunctionalComponent(__VLS_15);
const __VLS_17 = __VLS_16({ ...{}, class: ("fa fa-th-list"), }, ...__VLS_functionalComponentArgsRest(__VLS_16));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_15, typeof __VLS_17> & Record<string, unknown>) => void)({ ...{}, class: ("fa fa-th-list"), });
const __VLS_18 = __VLS_pickFunctionalComponentCtx(__VLS_15, __VLS_17)!;
let __VLS_19!: __VLS_NormalizeEmits<typeof __VLS_18.emit>;
}
(__VLS_13.slots!).default;
}
{
const __VLS_20 = __VLS_intrinsicElements["br"];
const __VLS_21 = __VLS_elementAsFunctionalComponent(__VLS_20);
const __VLS_22 = __VLS_21({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_21));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_20, typeof __VLS_22> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_23 = __VLS_pickFunctionalComponentCtx(__VLS_20, __VLS_22)!;
let __VLS_24!: __VLS_NormalizeEmits<typeof __VLS_23.emit>;
}
{
const __VLS_25 = __VLS_intrinsicElements["button"];
const __VLS_26 = __VLS_elementAsFunctionalComponent(__VLS_25);
const __VLS_27 = __VLS_26({ ...{ onClick: {} as any, }, type: ("button"), class: ("btn btn-secondary"), }, ...__VLS_functionalComponentArgsRest(__VLS_26));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_25, typeof __VLS_27> & Record<string, unknown>) => void)({ ...{ onClick: {} as any, }, type: ("button"), class: ("btn btn-secondary"), });
const __VLS_28 = __VLS_pickFunctionalComponentCtx(__VLS_25, __VLS_27)!;
let __VLS_29!: __VLS_NormalizeEmits<typeof __VLS_28.emit>;
let __VLS_30 = { 'click': __VLS_pickEvent(__VLS_29['click'], ({} as __VLS_FunctionalComponentProps<typeof __VLS_26, typeof __VLS_27>).onClick) };
__VLS_30 = {
click: $event => {
__VLS_ctx.abrirModal('articulo', 'registrar');
// @ts-ignore
[abrirModal,];
}
};
{
const __VLS_31 = __VLS_intrinsicElements["i"];
const __VLS_32 = __VLS_elementAsFunctionalComponent(__VLS_31);
const __VLS_33 = __VLS_32({ ...{}, class: ("fa fa-plus"), }, ...__VLS_functionalComponentArgsRest(__VLS_32));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_31, typeof __VLS_33> & Record<string, unknown>) => void)({ ...{}, class: ("fa fa-plus"), });
const __VLS_34 = __VLS_pickFunctionalComponentCtx(__VLS_31, __VLS_33)!;
let __VLS_35!: __VLS_NormalizeEmits<typeof __VLS_34.emit>;
}
(__VLS_28.slots!).default;
}
{
const __VLS_36 = __VLS_intrinsicElements["button"];
const __VLS_37 = __VLS_elementAsFunctionalComponent(__VLS_36);
const __VLS_38 = __VLS_37({ ...{ onClick: {} as any, }, type: ("button"), class: ("btn bta-info"), }, ...__VLS_functionalComponentArgsRest(__VLS_37));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_36, typeof __VLS_38> & Record<string, unknown>) => void)({ ...{ onClick: {} as any, }, type: ("button"), class: ("btn bta-info"), });
const __VLS_39 = __VLS_pickFunctionalComponentCtx(__VLS_36, __VLS_38)!;
let __VLS_40!: __VLS_NormalizeEmits<typeof __VLS_39.emit>;
let __VLS_41 = { 'click': __VLS_pickEvent(__VLS_40['click'], ({} as __VLS_FunctionalComponentProps<typeof __VLS_37, typeof __VLS_38>).onClick) };
__VLS_41 = {
click: $event => {
__VLS_ctx.cargarPdf();
// @ts-ignore
[cargarPdf,];
}
};
{
const __VLS_42 = __VLS_intrinsicElements["i"];
const __VLS_43 = __VLS_elementAsFunctionalComponent(__VLS_42);
const __VLS_44 = __VLS_43({ ...{}, class: ("fa fa-file-pdf"), }, ...__VLS_functionalComponentArgsRest(__VLS_43));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_42, typeof __VLS_44> & Record<string, unknown>) => void)({ ...{}, class: ("fa fa-file-pdf"), });
const __VLS_45 = __VLS_pickFunctionalComponentCtx(__VLS_42, __VLS_44)!;
let __VLS_46!: __VLS_NormalizeEmits<typeof __VLS_45.emit>;
}
(__VLS_39.slots!).default;
}
(__VLS_8.slots!).default;
}
(__VLS_3.slots!).default;
}
{
const __VLS_47 = __VLS_intrinsicElements["div"];
const __VLS_48 = __VLS_elementAsFunctionalComponent(__VLS_47);
const __VLS_49 = __VLS_48({ ...{}, class: ("form-group row"), }, ...__VLS_functionalComponentArgsRest(__VLS_48));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_47, typeof __VLS_49> & Record<string, unknown>) => void)({ ...{}, class: ("form-group row"), });
const __VLS_50 = __VLS_pickFunctionalComponentCtx(__VLS_47, __VLS_49)!;
let __VLS_51!: __VLS_NormalizeEmits<typeof __VLS_50.emit>;
{
const __VLS_52 = __VLS_intrinsicElements["div"];
const __VLS_53 = __VLS_elementAsFunctionalComponent(__VLS_52);
const __VLS_54 = __VLS_53({ ...{}, class: ("col-md-6"), }, ...__VLS_functionalComponentArgsRest(__VLS_53));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_52, typeof __VLS_54> & Record<string, unknown>) => void)({ ...{}, class: ("col-md-6"), });
const __VLS_55 = __VLS_pickFunctionalComponentCtx(__VLS_52, __VLS_54)!;
let __VLS_56!: __VLS_NormalizeEmits<typeof __VLS_55.emit>;
{
const __VLS_57 = __VLS_intrinsicElements["div"];
const __VLS_58 = __VLS_elementAsFunctionalComponent(__VLS_57);
const __VLS_59 = __VLS_58({ ...{}, class: ("input-group"), }, ...__VLS_functionalComponentArgsRest(__VLS_58));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_57, typeof __VLS_59> & Record<string, unknown>) => void)({ ...{}, class: ("input-group"), });
const __VLS_60 = __VLS_pickFunctionalComponentCtx(__VLS_57, __VLS_59)!;
let __VLS_61!: __VLS_NormalizeEmits<typeof __VLS_60.emit>;
{
const __VLS_62 = __VLS_intrinsicElements["select"];
const __VLS_63 = __VLS_elementAsFunctionalComponent(__VLS_62);
const __VLS_64 = __VLS_63({ ...{}, class: ("form-control col-md-3"), value: ((__VLS_ctx.criterio)), }, ...__VLS_functionalComponentArgsRest(__VLS_63));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_62, typeof __VLS_64> & Record<string, unknown>) => void)({ ...{}, class: ("form-control col-md-3"), value: ((__VLS_ctx.criterio)), });
const __VLS_65 = __VLS_pickFunctionalComponentCtx(__VLS_62, __VLS_64)!;
let __VLS_66!: __VLS_NormalizeEmits<typeof __VLS_65.emit>;
{
const __VLS_67 = __VLS_intrinsicElements["option"];
const __VLS_68 = __VLS_elementAsFunctionalComponent(__VLS_67);
const __VLS_69 = __VLS_68({ ...{}, value: ("nombre"), }, ...__VLS_functionalComponentArgsRest(__VLS_68));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_67, typeof __VLS_69> & Record<string, unknown>) => void)({ ...{}, value: ("nombre"), });
const __VLS_70 = __VLS_pickFunctionalComponentCtx(__VLS_67, __VLS_69)!;
let __VLS_71!: __VLS_NormalizeEmits<typeof __VLS_70.emit>;
(__VLS_70.slots!).default;
}
{
const __VLS_72 = __VLS_intrinsicElements["option"];
const __VLS_73 = __VLS_elementAsFunctionalComponent(__VLS_72);
const __VLS_74 = __VLS_73({ ...{}, value: ("descripcion"), }, ...__VLS_functionalComponentArgsRest(__VLS_73));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_72, typeof __VLS_74> & Record<string, unknown>) => void)({ ...{}, value: ("descripcion"), });
const __VLS_75 = __VLS_pickFunctionalComponentCtx(__VLS_72, __VLS_74)!;
let __VLS_76!: __VLS_NormalizeEmits<typeof __VLS_75.emit>;
(__VLS_75.slots!).default;
}
(__VLS_65.slots!).default;
}
{
const __VLS_77 = __VLS_intrinsicElements["input"];
const __VLS_78 = __VLS_elementAsFunctionalComponent(__VLS_77);
const __VLS_79 = __VLS_78({ ...{ onKeyup: {} as any, }, type: ("text"), value: ((__VLS_ctx.buscar)), class: ("form-control"), placeholder: ("Texto a buscar"), }, ...__VLS_functionalComponentArgsRest(__VLS_78));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_77, typeof __VLS_79> & Record<string, unknown>) => void)({ ...{ onKeyup: {} as any, }, type: ("text"), value: ((__VLS_ctx.buscar)), class: ("form-control"), placeholder: ("Texto a buscar"), });
const __VLS_80 = __VLS_pickFunctionalComponentCtx(__VLS_77, __VLS_79)!;
let __VLS_81!: __VLS_NormalizeEmits<typeof __VLS_80.emit>;
let __VLS_82 = { 'keyup': __VLS_pickEvent(__VLS_81['keyup'], ({} as __VLS_FunctionalComponentProps<typeof __VLS_78, typeof __VLS_79>).onKeyup) };
__VLS_82 = {
keyup: $event => {
__VLS_ctx.listarArticulo(1, __VLS_ctx.buscar, __VLS_ctx.criterio);
// @ts-ignore
[criterio, criterio, buscar, buscar, listarArticulo, buscar, criterio,];
}
};
}
{
const __VLS_83 = __VLS_intrinsicElements["button"];
const __VLS_84 = __VLS_elementAsFunctionalComponent(__VLS_83);
const __VLS_85 = __VLS_84({ ...{ onClick: {} as any, }, type: ("submit"), class: ("btn btn-primary"), }, ...__VLS_functionalComponentArgsRest(__VLS_84));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_83, typeof __VLS_85> & Record<string, unknown>) => void)({ ...{ onClick: {} as any, }, type: ("submit"), class: ("btn btn-primary"), });
const __VLS_86 = __VLS_pickFunctionalComponentCtx(__VLS_83, __VLS_85)!;
let __VLS_87!: __VLS_NormalizeEmits<typeof __VLS_86.emit>;
let __VLS_88 = { 'click': __VLS_pickEvent(__VLS_87['click'], ({} as __VLS_FunctionalComponentProps<typeof __VLS_84, typeof __VLS_85>).onClick) };
__VLS_88 = {
click: $event => {
__VLS_ctx.listarArticulo(1, __VLS_ctx.buscar, __VLS_ctx.criterio);
// @ts-ignore
[listarArticulo, buscar, criterio,];
}
};
{
const __VLS_89 = __VLS_intrinsicElements["i"];
const __VLS_90 = __VLS_elementAsFunctionalComponent(__VLS_89);
const __VLS_91 = __VLS_90({ ...{}, class: ("fa fa-search"), }, ...__VLS_functionalComponentArgsRest(__VLS_90));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_89, typeof __VLS_91> & Record<string, unknown>) => void)({ ...{}, class: ("fa fa-search"), });
const __VLS_92 = __VLS_pickFunctionalComponentCtx(__VLS_89, __VLS_91)!;
let __VLS_93!: __VLS_NormalizeEmits<typeof __VLS_92.emit>;
}
(__VLS_86.slots!).default;
}
(__VLS_60.slots!).default;
}
(__VLS_55.slots!).default;
}
(__VLS_50.slots!).default;
}
{
const __VLS_94 = __VLS_intrinsicElements["div"];
const __VLS_95 = __VLS_elementAsFunctionalComponent(__VLS_94);
const __VLS_96 = __VLS_95({ ...{}, class: ("row"), }, ...__VLS_functionalComponentArgsRest(__VLS_95));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_94, typeof __VLS_96> & Record<string, unknown>) => void)({ ...{}, class: ("row"), });
const __VLS_97 = __VLS_pickFunctionalComponentCtx(__VLS_94, __VLS_96)!;
let __VLS_98!: __VLS_NormalizeEmits<typeof __VLS_97.emit>;
{
const __VLS_99 = __VLS_intrinsicElements["div"];
const __VLS_100 = __VLS_elementAsFunctionalComponent(__VLS_99);
const __VLS_101 = __VLS_100({ ...{}, class: ("col-md-12"), }, ...__VLS_functionalComponentArgsRest(__VLS_100));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_99, typeof __VLS_101> & Record<string, unknown>) => void)({ ...{}, class: ("col-md-12"), });
const __VLS_102 = __VLS_pickFunctionalComponentCtx(__VLS_99, __VLS_101)!;
let __VLS_103!: __VLS_NormalizeEmits<typeof __VLS_102.emit>;
{
const __VLS_104 = __VLS_intrinsicElements["div"];
const __VLS_105 = __VLS_elementAsFunctionalComponent(__VLS_104);
const __VLS_106 = __VLS_105({ ...{}, class: ("tile"), }, ...__VLS_functionalComponentArgsRest(__VLS_105));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_104, typeof __VLS_106> & Record<string, unknown>) => void)({ ...{}, class: ("tile"), });
const __VLS_107 = __VLS_pickFunctionalComponentCtx(__VLS_104, __VLS_106)!;
let __VLS_108!: __VLS_NormalizeEmits<typeof __VLS_107.emit>;
{
const __VLS_109 = __VLS_intrinsicElements["div"];
const __VLS_110 = __VLS_elementAsFunctionalComponent(__VLS_109);
const __VLS_111 = __VLS_110({ ...{}, class: ("tile-body table-responsive"), }, ...__VLS_functionalComponentArgsRest(__VLS_110));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_109, typeof __VLS_111> & Record<string, unknown>) => void)({ ...{}, class: ("tile-body table-responsive"), });
const __VLS_112 = __VLS_pickFunctionalComponentCtx(__VLS_109, __VLS_111)!;
let __VLS_113!: __VLS_NormalizeEmits<typeof __VLS_112.emit>;
{
const __VLS_114 = __VLS_intrinsicElements["table"];
const __VLS_115 = __VLS_elementAsFunctionalComponent(__VLS_114);
const __VLS_116 = __VLS_115({ ...{}, class: ("table table-hover table-bordered"), id: ("sampleTable"), }, ...__VLS_functionalComponentArgsRest(__VLS_115));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_114, typeof __VLS_116> & Record<string, unknown>) => void)({ ...{}, class: ("table table-hover table-bordered"), id: ("sampleTable"), });
const __VLS_117 = __VLS_pickFunctionalComponentCtx(__VLS_114, __VLS_116)!;
let __VLS_118!: __VLS_NormalizeEmits<typeof __VLS_117.emit>;
{
const __VLS_119 = __VLS_intrinsicElements["thead"];
const __VLS_120 = __VLS_elementAsFunctionalComponent(__VLS_119);
const __VLS_121 = __VLS_120({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_120));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_119, typeof __VLS_121> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_122 = __VLS_pickFunctionalComponentCtx(__VLS_119, __VLS_121)!;
let __VLS_123!: __VLS_NormalizeEmits<typeof __VLS_122.emit>;
{
const __VLS_124 = __VLS_intrinsicElements["tr"];
const __VLS_125 = __VLS_elementAsFunctionalComponent(__VLS_124);
const __VLS_126 = __VLS_125({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_125));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_124, typeof __VLS_126> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_127 = __VLS_pickFunctionalComponentCtx(__VLS_124, __VLS_126)!;
let __VLS_128!: __VLS_NormalizeEmits<typeof __VLS_127.emit>;
{
const __VLS_129 = __VLS_intrinsicElements["th"];
const __VLS_130 = __VLS_elementAsFunctionalComponent(__VLS_129);
const __VLS_131 = __VLS_130({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_130));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_129, typeof __VLS_131> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_132 = __VLS_pickFunctionalComponentCtx(__VLS_129, __VLS_131)!;
let __VLS_133!: __VLS_NormalizeEmits<typeof __VLS_132.emit>;
(__VLS_132.slots!).default;
}
{
const __VLS_134 = __VLS_intrinsicElements["th"];
const __VLS_135 = __VLS_elementAsFunctionalComponent(__VLS_134);
const __VLS_136 = __VLS_135({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_135));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_134, typeof __VLS_136> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_137 = __VLS_pickFunctionalComponentCtx(__VLS_134, __VLS_136)!;
let __VLS_138!: __VLS_NormalizeEmits<typeof __VLS_137.emit>;
(__VLS_137.slots!).default;
}
{
const __VLS_139 = __VLS_intrinsicElements["th"];
const __VLS_140 = __VLS_elementAsFunctionalComponent(__VLS_139);
const __VLS_141 = __VLS_140({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_140));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_139, typeof __VLS_141> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_142 = __VLS_pickFunctionalComponentCtx(__VLS_139, __VLS_141)!;
let __VLS_143!: __VLS_NormalizeEmits<typeof __VLS_142.emit>;
(__VLS_142.slots!).default;
}
{
const __VLS_144 = __VLS_intrinsicElements["th"];
const __VLS_145 = __VLS_elementAsFunctionalComponent(__VLS_144);
const __VLS_146 = __VLS_145({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_145));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_144, typeof __VLS_146> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_147 = __VLS_pickFunctionalComponentCtx(__VLS_144, __VLS_146)!;
let __VLS_148!: __VLS_NormalizeEmits<typeof __VLS_147.emit>;
(__VLS_147.slots!).default;
}
{
const __VLS_149 = __VLS_intrinsicElements["th"];
const __VLS_150 = __VLS_elementAsFunctionalComponent(__VLS_149);
const __VLS_151 = __VLS_150({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_150));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_149, typeof __VLS_151> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_152 = __VLS_pickFunctionalComponentCtx(__VLS_149, __VLS_151)!;
let __VLS_153!: __VLS_NormalizeEmits<typeof __VLS_152.emit>;
(__VLS_152.slots!).default;
}
{
const __VLS_154 = __VLS_intrinsicElements["th"];
const __VLS_155 = __VLS_elementAsFunctionalComponent(__VLS_154);
const __VLS_156 = __VLS_155({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_155));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_154, typeof __VLS_156> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_157 = __VLS_pickFunctionalComponentCtx(__VLS_154, __VLS_156)!;
let __VLS_158!: __VLS_NormalizeEmits<typeof __VLS_157.emit>;
(__VLS_157.slots!).default;
}
{
const __VLS_159 = __VLS_intrinsicElements["th"];
const __VLS_160 = __VLS_elementAsFunctionalComponent(__VLS_159);
const __VLS_161 = __VLS_160({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_160));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_159, typeof __VLS_161> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_162 = __VLS_pickFunctionalComponentCtx(__VLS_159, __VLS_161)!;
let __VLS_163!: __VLS_NormalizeEmits<typeof __VLS_162.emit>;
(__VLS_162.slots!).default;
}
{
const __VLS_164 = __VLS_intrinsicElements["th"];
const __VLS_165 = __VLS_elementAsFunctionalComponent(__VLS_164);
const __VLS_166 = __VLS_165({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_165));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_164, typeof __VLS_166> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_167 = __VLS_pickFunctionalComponentCtx(__VLS_164, __VLS_166)!;
let __VLS_168!: __VLS_NormalizeEmits<typeof __VLS_167.emit>;
(__VLS_167.slots!).default;
}
{
const __VLS_169 = __VLS_intrinsicElements["th"];
const __VLS_170 = __VLS_elementAsFunctionalComponent(__VLS_169);
const __VLS_171 = __VLS_170({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_170));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_169, typeof __VLS_171> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_172 = __VLS_pickFunctionalComponentCtx(__VLS_169, __VLS_171)!;
let __VLS_173!: __VLS_NormalizeEmits<typeof __VLS_172.emit>;
(__VLS_172.slots!).default;
}
{
const __VLS_174 = __VLS_intrinsicElements["th"];
const __VLS_175 = __VLS_elementAsFunctionalComponent(__VLS_174);
const __VLS_176 = __VLS_175({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_175));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_174, typeof __VLS_176> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_177 = __VLS_pickFunctionalComponentCtx(__VLS_174, __VLS_176)!;
let __VLS_178!: __VLS_NormalizeEmits<typeof __VLS_177.emit>;
(__VLS_177.slots!).default;
}
(__VLS_127.slots!).default;
}
(__VLS_122.slots!).default;
}
{
const __VLS_179 = __VLS_intrinsicElements["tbody"];
const __VLS_180 = __VLS_elementAsFunctionalComponent(__VLS_179);
const __VLS_181 = __VLS_180({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_180));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_179, typeof __VLS_181> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_182 = __VLS_pickFunctionalComponentCtx(__VLS_179, __VLS_181)!;
let __VLS_183!: __VLS_NormalizeEmits<typeof __VLS_182.emit>;
for (const [articulo] of __VLS_getVForSourceType((__VLS_ctx.arrayArticulo)!)) {
{
const __VLS_184 = __VLS_intrinsicElements["tr"];
const __VLS_185 = __VLS_elementAsFunctionalComponent(__VLS_184);
const __VLS_186 = __VLS_185({ ...{}, key: ((articulo.id)), }, ...__VLS_functionalComponentArgsRest(__VLS_185));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_184, typeof __VLS_186> & Record<string, unknown>) => void)({ ...{}, key: ((articulo.id)), });
const __VLS_187 = __VLS_pickFunctionalComponentCtx(__VLS_184, __VLS_186)!;
let __VLS_188!: __VLS_NormalizeEmits<typeof __VLS_187.emit>;
{
const __VLS_189 = __VLS_intrinsicElements["td"];
const __VLS_190 = __VLS_elementAsFunctionalComponent(__VLS_189);
const __VLS_191 = __VLS_190({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_190));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_189, typeof __VLS_191> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_192 = __VLS_pickFunctionalComponentCtx(__VLS_189, __VLS_191)!;
let __VLS_193!: __VLS_NormalizeEmits<typeof __VLS_192.emit>;
__VLS_directiveFunction(__VLS_ctx.vText)((articulo.unidad));
}
{
const __VLS_194 = __VLS_intrinsicElements["td"];
const __VLS_195 = __VLS_elementAsFunctionalComponent(__VLS_194);
const __VLS_196 = __VLS_195({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_195));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_194, typeof __VLS_196> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_197 = __VLS_pickFunctionalComponentCtx(__VLS_194, __VLS_196)!;
let __VLS_198!: __VLS_NormalizeEmits<typeof __VLS_197.emit>;
__VLS_directiveFunction(__VLS_ctx.vText)((articulo.codigo));
}
{
const __VLS_199 = __VLS_intrinsicElements["td"];
const __VLS_200 = __VLS_elementAsFunctionalComponent(__VLS_199);
const __VLS_201 = __VLS_200({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_200));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_199, typeof __VLS_201> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_202 = __VLS_pickFunctionalComponentCtx(__VLS_199, __VLS_201)!;
let __VLS_203!: __VLS_NormalizeEmits<typeof __VLS_202.emit>;
__VLS_directiveFunction(__VLS_ctx.vText)((articulo.nom_contable));
}
{
const __VLS_204 = __VLS_intrinsicElements["td"];
const __VLS_205 = __VLS_elementAsFunctionalComponent(__VLS_204);
const __VLS_206 = __VLS_205({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_205));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_204, typeof __VLS_206> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_207 = __VLS_pickFunctionalComponentCtx(__VLS_204, __VLS_206)!;
let __VLS_208!: __VLS_NormalizeEmits<typeof __VLS_207.emit>;
__VLS_directiveFunction(__VLS_ctx.vText)((articulo.auxiliar));
}
{
const __VLS_209 = __VLS_intrinsicElements["td"];
const __VLS_210 = __VLS_elementAsFunctionalComponent(__VLS_209);
const __VLS_211 = __VLS_210({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_210));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_209, typeof __VLS_211> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_212 = __VLS_pickFunctionalComponentCtx(__VLS_209, __VLS_211)!;
let __VLS_213!: __VLS_NormalizeEmits<typeof __VLS_212.emit>;
__VLS_directiveFunction(__VLS_ctx.vText)((articulo.vidautil));
}
{
const __VLS_214 = __VLS_intrinsicElements["td"];
const __VLS_215 = __VLS_elementAsFunctionalComponent(__VLS_214);
const __VLS_216 = __VLS_215({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_215));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_214, typeof __VLS_216> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_217 = __VLS_pickFunctionalComponentCtx(__VLS_214, __VLS_216)!;
let __VLS_218!: __VLS_NormalizeEmits<typeof __VLS_217.emit>;
__VLS_directiveFunction(__VLS_ctx.vText)((articulo.oficina));
}
{
const __VLS_219 = __VLS_intrinsicElements["td"];
const __VLS_220 = __VLS_elementAsFunctionalComponent(__VLS_219);
const __VLS_221 = __VLS_220({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_220));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_219, typeof __VLS_221> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_222 = __VLS_pickFunctionalComponentCtx(__VLS_219, __VLS_221)!;
let __VLS_223!: __VLS_NormalizeEmits<typeof __VLS_222.emit>;
__VLS_directiveFunction(__VLS_ctx.vText)((articulo.responsable));
}
{
const __VLS_224 = __VLS_intrinsicElements["td"];
const __VLS_225 = __VLS_elementAsFunctionalComponent(__VLS_224);
const __VLS_226 = __VLS_225({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_225));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_224, typeof __VLS_226> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_227 = __VLS_pickFunctionalComponentCtx(__VLS_224, __VLS_226)!;
let __VLS_228!: __VLS_NormalizeEmits<typeof __VLS_227.emit>;
__VLS_directiveFunction(__VLS_ctx.vText)((articulo.descripcion));
}
{
const __VLS_229 = __VLS_intrinsicElements["td"];
const __VLS_230 = __VLS_elementAsFunctionalComponent(__VLS_229);
const __VLS_231 = __VLS_230({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_230));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_229, typeof __VLS_231> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_232 = __VLS_pickFunctionalComponentCtx(__VLS_229, __VLS_231)!;
let __VLS_233!: __VLS_NormalizeEmits<typeof __VLS_232.emit>;
if (articulo.condicion) {
{
const __VLS_234 = __VLS_intrinsicElements["div"];
const __VLS_235 = __VLS_elementAsFunctionalComponent(__VLS_234);
const __VLS_236 = __VLS_235({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_235));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_234, typeof __VLS_236> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_237 = __VLS_pickFunctionalComponentCtx(__VLS_234, __VLS_236)!;
let __VLS_238!: __VLS_NormalizeEmits<typeof __VLS_237.emit>;
{
const __VLS_239 = __VLS_intrinsicElements["span"];
const __VLS_240 = __VLS_elementAsFunctionalComponent(__VLS_239);
const __VLS_241 = __VLS_240({ ...{}, class: ("badge badge-success"), }, ...__VLS_functionalComponentArgsRest(__VLS_240));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_239, typeof __VLS_241> & Record<string, unknown>) => void)({ ...{}, class: ("badge badge-success"), });
const __VLS_242 = __VLS_pickFunctionalComponentCtx(__VLS_239, __VLS_241)!;
let __VLS_243!: __VLS_NormalizeEmits<typeof __VLS_242.emit>;
(__VLS_242.slots!).default;
}
(__VLS_237.slots!).default;
}
// @ts-ignore
[arrayArticulo,];
}
else {
{
const __VLS_244 = __VLS_intrinsicElements["div"];
const __VLS_245 = __VLS_elementAsFunctionalComponent(__VLS_244);
const __VLS_246 = __VLS_245({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_245));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_244, typeof __VLS_246> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_247 = __VLS_pickFunctionalComponentCtx(__VLS_244, __VLS_246)!;
let __VLS_248!: __VLS_NormalizeEmits<typeof __VLS_247.emit>;
{
const __VLS_249 = __VLS_intrinsicElements["span"];
const __VLS_250 = __VLS_elementAsFunctionalComponent(__VLS_249);
const __VLS_251 = __VLS_250({ ...{}, class: ("badge badge-danger"), }, ...__VLS_functionalComponentArgsRest(__VLS_250));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_249, typeof __VLS_251> & Record<string, unknown>) => void)({ ...{}, class: ("badge badge-danger"), });
const __VLS_252 = __VLS_pickFunctionalComponentCtx(__VLS_249, __VLS_251)!;
let __VLS_253!: __VLS_NormalizeEmits<typeof __VLS_252.emit>;
(__VLS_252.slots!).default;
}
(__VLS_247.slots!).default;
}
}
(__VLS_232.slots!).default;
}
{
const __VLS_254 = __VLS_intrinsicElements["td"];
const __VLS_255 = __VLS_elementAsFunctionalComponent(__VLS_254);
const __VLS_256 = __VLS_255({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_255));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_254, typeof __VLS_256> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_257 = __VLS_pickFunctionalComponentCtx(__VLS_254, __VLS_256)!;
let __VLS_258!: __VLS_NormalizeEmits<typeof __VLS_257.emit>;
{
const __VLS_259 = __VLS_intrinsicElements["button"];
const __VLS_260 = __VLS_elementAsFunctionalComponent(__VLS_259);
const __VLS_261 = __VLS_260({ ...{ onClick: {} as any, }, type: ("button"), class: ("btn btn-warning btn-sm"), }, ...__VLS_functionalComponentArgsRest(__VLS_260));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_259, typeof __VLS_261> & Record<string, unknown>) => void)({ ...{ onClick: {} as any, }, type: ("button"), class: ("btn btn-warning btn-sm"), });
const __VLS_262 = __VLS_pickFunctionalComponentCtx(__VLS_259, __VLS_261)!;
let __VLS_263!: __VLS_NormalizeEmits<typeof __VLS_262.emit>;
let __VLS_264 = { 'click': __VLS_pickEvent(__VLS_263['click'], ({} as __VLS_FunctionalComponentProps<typeof __VLS_260, typeof __VLS_261>).onClick) };
__VLS_264 = {
click: $event => {
__VLS_ctx.abrirModal('articulo', 'actualizar', articulo);
// @ts-ignore
[abrirModal,];
}
};
{
const __VLS_265 = __VLS_intrinsicElements["i"];
const __VLS_266 = __VLS_elementAsFunctionalComponent(__VLS_265);
const __VLS_267 = __VLS_266({ ...{}, class: ("fa fa-edit"), }, ...__VLS_functionalComponentArgsRest(__VLS_266));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_265, typeof __VLS_267> & Record<string, unknown>) => void)({ ...{}, class: ("fa fa-edit"), });
const __VLS_268 = __VLS_pickFunctionalComponentCtx(__VLS_265, __VLS_267)!;
let __VLS_269!: __VLS_NormalizeEmits<typeof __VLS_268.emit>;
}
(__VLS_262.slots!).default;
}
if (articulo.condicion) {
{
const __VLS_270 = __VLS_intrinsicElements["button"];
const __VLS_271 = __VLS_elementAsFunctionalComponent(__VLS_270);
const __VLS_272 = __VLS_271({ ...{ onClick: {} as any, }, type: ("button"), class: ("btn btn-danger btn-sm"), }, ...__VLS_functionalComponentArgsRest(__VLS_271));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_270, typeof __VLS_272> & Record<string, unknown>) => void)({ ...{ onClick: {} as any, }, type: ("button"), class: ("btn btn-danger btn-sm"), });
const __VLS_273 = __VLS_pickFunctionalComponentCtx(__VLS_270, __VLS_272)!;
let __VLS_274!: __VLS_NormalizeEmits<typeof __VLS_273.emit>;
let __VLS_275 = { 'click': __VLS_pickEvent(__VLS_274['click'], ({} as __VLS_FunctionalComponentProps<typeof __VLS_271, typeof __VLS_272>).onClick) };
__VLS_275 = {
click: $event => {
if (!((articulo.condicion))) return;
__VLS_ctx.desactivarArticulo(articulo.id);
// @ts-ignore
[desactivarArticulo,];
}
};
{
const __VLS_276 = __VLS_intrinsicElements["i"];
const __VLS_277 = __VLS_elementAsFunctionalComponent(__VLS_276);
const __VLS_278 = __VLS_277({ ...{}, class: ("fa fa-trash"), }, ...__VLS_functionalComponentArgsRest(__VLS_277));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_276, typeof __VLS_278> & Record<string, unknown>) => void)({ ...{}, class: ("fa fa-trash"), });
const __VLS_279 = __VLS_pickFunctionalComponentCtx(__VLS_276, __VLS_278)!;
let __VLS_280!: __VLS_NormalizeEmits<typeof __VLS_279.emit>;
}
(__VLS_273.slots!).default;
}
}
else {
{
const __VLS_281 = __VLS_intrinsicElements["button"];
const __VLS_282 = __VLS_elementAsFunctionalComponent(__VLS_281);
const __VLS_283 = __VLS_282({ ...{ onClick: {} as any, }, type: ("button"), class: ("btn btn-info btn-sm"), }, ...__VLS_functionalComponentArgsRest(__VLS_282));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_281, typeof __VLS_283> & Record<string, unknown>) => void)({ ...{ onClick: {} as any, }, type: ("button"), class: ("btn btn-info btn-sm"), });
const __VLS_284 = __VLS_pickFunctionalComponentCtx(__VLS_281, __VLS_283)!;
let __VLS_285!: __VLS_NormalizeEmits<typeof __VLS_284.emit>;
let __VLS_286 = { 'click': __VLS_pickEvent(__VLS_285['click'], ({} as __VLS_FunctionalComponentProps<typeof __VLS_282, typeof __VLS_283>).onClick) };
__VLS_286 = {
click: $event => {
if (!(!((articulo.condicion)))) return;
__VLS_ctx.activarArticulo(articulo.id);
// @ts-ignore
[activarArticulo,];
}
};
{
const __VLS_287 = __VLS_intrinsicElements["i"];
const __VLS_288 = __VLS_elementAsFunctionalComponent(__VLS_287);
const __VLS_289 = __VLS_288({ ...{}, class: ("fa fa-check"), }, ...__VLS_functionalComponentArgsRest(__VLS_288));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_287, typeof __VLS_289> & Record<string, unknown>) => void)({ ...{}, class: ("fa fa-check"), });
const __VLS_290 = __VLS_pickFunctionalComponentCtx(__VLS_287, __VLS_289)!;
let __VLS_291!: __VLS_NormalizeEmits<typeof __VLS_290.emit>;
}
(__VLS_284.slots!).default;
}
}
(__VLS_257.slots!).default;
}
(__VLS_187.slots!).default;
}
}
(__VLS_182.slots!).default;
}
(__VLS_117.slots!).default;
}
{
const __VLS_292 = __VLS_intrinsicElements["nav"];
const __VLS_293 = __VLS_elementAsFunctionalComponent(__VLS_292);
const __VLS_294 = __VLS_293({ ...{}, }, ...__VLS_functionalComponentArgsRest(__VLS_293));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_292, typeof __VLS_294> & Record<string, unknown>) => void)({ ...{}, });
const __VLS_295 = __VLS_pickFunctionalComponentCtx(__VLS_292, __VLS_294)!;
let __VLS_296!: __VLS_NormalizeEmits<typeof __VLS_295.emit>;
{
const __VLS_297 = __VLS_intrinsicElements["ul"];
const __VLS_298 = __VLS_elementAsFunctionalComponent(__VLS_297);
const __VLS_299 = __VLS_298({ ...{}, class: ("pagination"), }, ...__VLS_functionalComponentArgsRest(__VLS_298));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_297, typeof __VLS_299> & Record<string, unknown>) => void)({ ...{}, class: ("pagination"), });
const __VLS_300 = __VLS_pickFunctionalComponentCtx(__VLS_297, __VLS_299)!;
let __VLS_301!: __VLS_NormalizeEmits<typeof __VLS_300.emit>;
if (__VLS_ctx.pagination.current_page > 1) {
{
const __VLS_302 = __VLS_intrinsicElements["li"];
const __VLS_303 = __VLS_elementAsFunctionalComponent(__VLS_302);
const __VLS_304 = __VLS_303({ ...{}, class: ("page-item"), }, ...__VLS_functionalComponentArgsRest(__VLS_303));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_302, typeof __VLS_304> & Record<string, unknown>) => void)({ ...{}, class: ("page-item"), });
const __VLS_305 = __VLS_pickFunctionalComponentCtx(__VLS_302, __VLS_304)!;
let __VLS_306!: __VLS_NormalizeEmits<typeof __VLS_305.emit>;
{
const __VLS_307 = __VLS_intrinsicElements["a"];
const __VLS_308 = __VLS_elementAsFunctionalComponent(__VLS_307);
const __VLS_309 = __VLS_308({ ...{ onClick: {} as any, }, class: ("page-link"), href: ("#"), }, ...__VLS_functionalComponentArgsRest(__VLS_308));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_307, typeof __VLS_309> & Record<string, unknown>) => void)({ ...{ onClick: {} as any, }, class: ("page-link"), href: ("#"), });
const __VLS_310 = __VLS_pickFunctionalComponentCtx(__VLS_307, __VLS_309)!;
let __VLS_311!: __VLS_NormalizeEmits<typeof __VLS_310.emit>;
let __VLS_312 = { 'click': __VLS_pickEvent(__VLS_311['click'], ({} as __VLS_FunctionalComponentProps<typeof __VLS_308, typeof __VLS_309>).onClick) };
__VLS_312 = {
click: $event => {
if (!((__VLS_ctx.pagination.current_page > 1))) return;
__VLS_ctx.cambiarPagina(__VLS_ctx.pagination.current_page - 1, __VLS_ctx.buscar, __VLS_ctx.criterio);
// @ts-ignore
[pagination, cambiarPagina, pagination, buscar, criterio,];
}
};
(__VLS_310.slots!).default;
}
(__VLS_305.slots!).default;
}
}
for (const [page] of __VLS_getVForSourceType((__VLS_ctx.pagesNumber)!)) {
{
const __VLS_313 = __VLS_intrinsicElements["li"];
const __VLS_314 = __VLS_elementAsFunctionalComponent(__VLS_313);
const __VLS_315 = __VLS_314({ ...{}, class: ("page-item"), key: ((page)), }, ...__VLS_functionalComponentArgsRest(__VLS_314));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_313, typeof __VLS_315> & Record<string, unknown>) => void)({ ...{}, class: ("page-item"), key: ((page)), });
const __VLS_316 = __VLS_pickFunctionalComponentCtx(__VLS_313, __VLS_315)!;
let __VLS_317!: __VLS_NormalizeEmits<typeof __VLS_316.emit>;
([page == __VLS_ctx.isActived ? 'active' : '']);
{
const __VLS_318 = __VLS_intrinsicElements["a"];
const __VLS_319 = __VLS_elementAsFunctionalComponent(__VLS_318);
const __VLS_320 = __VLS_319({ ...{ onClick: {} as any, }, class: ("page-link"), href: ("#"), }, ...__VLS_functionalComponentArgsRest(__VLS_319));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_318, typeof __VLS_320> & Record<string, unknown>) => void)({ ...{ onClick: {} as any, }, class: ("page-link"), href: ("#"), });
const __VLS_321 = __VLS_pickFunctionalComponentCtx(__VLS_318, __VLS_320)!;
let __VLS_322!: __VLS_NormalizeEmits<typeof __VLS_321.emit>;
__VLS_directiveFunction(__VLS_ctx.vText)((page));
let __VLS_323 = { 'click': __VLS_pickEvent(__VLS_322['click'], ({} as __VLS_FunctionalComponentProps<typeof __VLS_319, typeof __VLS_320>).onClick) };
__VLS_323 = {
click: $event => {
__VLS_ctx.cambiarPagina(page, __VLS_ctx.buscar, __VLS_ctx.criterio);
// @ts-ignore
[pagesNumber, isActived, cambiarPagina, buscar, criterio,];
}
};
}
(__VLS_316.slots!).default;
}
}
if (__VLS_ctx.pagination.current_page < __VLS_ctx.pagination.last_page) {
{
const __VLS_324 = __VLS_intrinsicElements["li"];
const __VLS_325 = __VLS_elementAsFunctionalComponent(__VLS_324);
const __VLS_326 = __VLS_325({ ...{}, class: ("page-item"), }, ...__VLS_functionalComponentArgsRest(__VLS_325));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_324, typeof __VLS_326> & Record<string, unknown>) => void)({ ...{}, class: ("page-item"), });
const __VLS_327 = __VLS_pickFunctionalComponentCtx(__VLS_324, __VLS_326)!;
let __VLS_328!: __VLS_NormalizeEmits<typeof __VLS_327.emit>;
{
const __VLS_329 = __VLS_intrinsicElements["a"];
const __VLS_330 = __VLS_elementAsFunctionalComponent(__VLS_329);
const __VLS_331 = __VLS_330({ ...{ onClick: {} as any, }, class: ("page-link"), href: ("#"), }, ...__VLS_functionalComponentArgsRest(__VLS_330));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_329, typeof __VLS_331> & Record<string, unknown>) => void)({ ...{ onClick: {} as any, }, class: ("page-link"), href: ("#"), });
const __VLS_332 = __VLS_pickFunctionalComponentCtx(__VLS_329, __VLS_331)!;
let __VLS_333!: __VLS_NormalizeEmits<typeof __VLS_332.emit>;
let __VLS_334 = { 'click': __VLS_pickEvent(__VLS_333['click'], ({} as __VLS_FunctionalComponentProps<typeof __VLS_330, typeof __VLS_331>).onClick) };
__VLS_334 = {
click: $event => {
if (!((__VLS_ctx.pagination.current_page < __VLS_ctx.pagination.last_page))) return;
__VLS_ctx.cambiarPagina(__VLS_ctx.pagination.current_page + 1, __VLS_ctx.buscar, __VLS_ctx.criterio);
// @ts-ignore
[pagination, pagination, cambiarPagina, pagination, buscar, criterio,];
}
};
(__VLS_332.slots!).default;
}
(__VLS_327.slots!).default;
}
}
(__VLS_300.slots!).default;
}
(__VLS_295.slots!).default;
}
(__VLS_112.slots!).default;
}
(__VLS_107.slots!).default;
}
(__VLS_102.slots!).default;
}
(__VLS_97.slots!).default;
}
{
const __VLS_335 = __VLS_intrinsicElements["div"];
const __VLS_336 = __VLS_elementAsFunctionalComponent(__VLS_335);
const __VLS_337 = __VLS_336({ ...{}, class: ("modal fade"), tabindex: ("-1"), role: ("dialog"), "aria-labelledby": ("myModalLabel"), style: ({}), "aria-hidden": ("true"), }, ...__VLS_functionalComponentArgsRest(__VLS_336));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_335, typeof __VLS_337> & Record<string, unknown>) => void)({ ...{}, class: ("modal fade"), tabindex: ("-1"), role: ("dialog"), "aria-labelledby": ("myModalLabel"), style: ({}), "aria-hidden": ("true"), });
const __VLS_338 = __VLS_pickFunctionalComponentCtx(__VLS_335, __VLS_337)!;
let __VLS_339!: __VLS_NormalizeEmits<typeof __VLS_338.emit>;
({ 'mostrar': __VLS_ctx.modal });
{
const __VLS_340 = __VLS_intrinsicElements["div"];
const __VLS_341 = __VLS_elementAsFunctionalComponent(__VLS_340);
const __VLS_342 = __VLS_341({ ...{}, class: ("modal-dialog modal-primary modal-lg"), role: ("document"), }, ...__VLS_functionalComponentArgsRest(__VLS_341));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_340, typeof __VLS_342> & Record<string, unknown>) => void)({ ...{}, class: ("modal-dialog modal-primary modal-lg"), role: ("document"), });
const __VLS_343 = __VLS_pickFunctionalComponentCtx(__VLS_340, __VLS_342)!;
let __VLS_344!: __VLS_NormalizeEmits<typeof __VLS_343.emit>;
{
const __VLS_345 = __VLS_intrinsicElements["div"];
const __VLS_346 = __VLS_elementAsFunctionalComponent(__VLS_345);
const __VLS_347 = __VLS_346({ ...{}, class: ("modal-content"), }, ...__VLS_functionalComponentArgsRest(__VLS_346));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_345, typeof __VLS_347> & Record<string, unknown>) => void)({ ...{}, class: ("modal-content"), });
const __VLS_348 = __VLS_pickFunctionalComponentCtx(__VLS_345, __VLS_347)!;
let __VLS_349!: __VLS_NormalizeEmits<typeof __VLS_348.emit>;
{
const __VLS_350 = __VLS_intrinsicElements["div"];
const __VLS_351 = __VLS_elementAsFunctionalComponent(__VLS_350);
const __VLS_352 = __VLS_351({ ...{}, class: ("modal-header"), }, ...__VLS_functionalComponentArgsRest(__VLS_351));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_350, typeof __VLS_352> & Record<string, unknown>) => void)({ ...{}, class: ("modal-header"), });
const __VLS_353 = __VLS_pickFunctionalComponentCtx(__VLS_350, __VLS_352)!;
let __VLS_354!: __VLS_NormalizeEmits<typeof __VLS_353.emit>;
{
const __VLS_355 = __VLS_intrinsicElements["h4"];
const __VLS_356 = __VLS_elementAsFunctionalComponent(__VLS_355);
const __VLS_357 = __VLS_356({ ...{}, class: ("modal-title"), }, ...__VLS_functionalComponentArgsRest(__VLS_356));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_355, typeof __VLS_357> & Record<string, unknown>) => void)({ ...{}, class: ("modal-title"), });
const __VLS_358 = __VLS_pickFunctionalComponentCtx(__VLS_355, __VLS_357)!;
let __VLS_359!: __VLS_NormalizeEmits<typeof __VLS_358.emit>;
__VLS_directiveFunction(__VLS_ctx.vText)((__VLS_ctx.tituloModal));
}
{
const __VLS_360 = __VLS_intrinsicElements["button"];
const __VLS_361 = __VLS_elementAsFunctionalComponent(__VLS_360);
const __VLS_362 = __VLS_361({ ...{ onClick: {} as any, }, type: ("button"), class: ("close"), "aria-label": ("Close"), }, ...__VLS_functionalComponentArgsRest(__VLS_361));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_360, typeof __VLS_362> & Record<string, unknown>) => void)({ ...{ onClick: {} as any, }, type: ("button"), class: ("close"), "aria-label": ("Close"), });
const __VLS_363 = __VLS_pickFunctionalComponentCtx(__VLS_360, __VLS_362)!;
let __VLS_364!: __VLS_NormalizeEmits<typeof __VLS_363.emit>;
let __VLS_365 = { 'click': __VLS_pickEvent(__VLS_364['click'], ({} as __VLS_FunctionalComponentProps<typeof __VLS_361, typeof __VLS_362>).onClick) };
__VLS_365 = {
click: $event => {
__VLS_ctx.cerrarModal();
// @ts-ignore
[modal, tituloModal, cerrarModal,];
}
};
{
const __VLS_366 = __VLS_intrinsicElements["span"];
const __VLS_367 = __VLS_elementAsFunctionalComponent(__VLS_366);
const __VLS_368 = __VLS_367({ ...{}, "aria-hidden": ("true"), }, ...__VLS_functionalComponentArgsRest(__VLS_367));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_366, typeof __VLS_368> & Record<string, unknown>) => void)({ ...{}, "aria-hidden": ("true"), });
const __VLS_369 = __VLS_pickFunctionalComponentCtx(__VLS_366, __VLS_368)!;
let __VLS_370!: __VLS_NormalizeEmits<typeof __VLS_369.emit>;
(__VLS_369.slots!).default;
}
(__VLS_363.slots!).default;
}
(__VLS_353.slots!).default;
}
{
const __VLS_371 = __VLS_intrinsicElements["div"];
const __VLS_372 = __VLS_elementAsFunctionalComponent(__VLS_371);
const __VLS_373 = __VLS_372({ ...{}, class: ("modal-body"), }, ...__VLS_functionalComponentArgsRest(__VLS_372));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_371, typeof __VLS_373> & Record<string, unknown>) => void)({ ...{}, class: ("modal-body"), });
const __VLS_374 = __VLS_pickFunctionalComponentCtx(__VLS_371, __VLS_373)!;
let __VLS_375!: __VLS_NormalizeEmits<typeof __VLS_374.emit>;
{
const __VLS_376 = __VLS_intrinsicElements["form"];
const __VLS_377 = __VLS_elementAsFunctionalComponent(__VLS_376);
const __VLS_378 = __VLS_377({ ...{}, action: (""), method: ("post"), enctype: ("multipart/form-data"), class: ("form-horizontal"), }, ...__VLS_functionalComponentArgsRest(__VLS_377));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_376, typeof __VLS_378> & Record<string, unknown>) => void)({ ...{}, action: (""), method: ("post"), enctype: ("multipart/form-data"), class: ("form-horizontal"), });
const __VLS_379 = __VLS_pickFunctionalComponentCtx(__VLS_376, __VLS_378)!;
let __VLS_380!: __VLS_NormalizeEmits<typeof __VLS_379.emit>;
{
const __VLS_381 = __VLS_intrinsicElements["div"];
const __VLS_382 = __VLS_elementAsFunctionalComponent(__VLS_381);
const __VLS_383 = __VLS_382({ ...{}, class: ("form-group row"), }, ...__VLS_functionalComponentArgsRest(__VLS_382));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_381, typeof __VLS_383> & Record<string, unknown>) => void)({ ...{}, class: ("form-group row"), });
const __VLS_384 = __VLS_pickFunctionalComponentCtx(__VLS_381, __VLS_383)!;
let __VLS_385!: __VLS_NormalizeEmits<typeof __VLS_384.emit>;
{
const __VLS_386 = __VLS_intrinsicElements["label"];
const __VLS_387 = __VLS_elementAsFunctionalComponent(__VLS_386);
const __VLS_388 = __VLS_387({ ...{}, class: ("col-md-3 form-control-label"), for: ("text-input"), }, ...__VLS_functionalComponentArgsRest(__VLS_387));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_386, typeof __VLS_388> & Record<string, unknown>) => void)({ ...{}, class: ("col-md-3 form-control-label"), for: ("text-input"), });
const __VLS_389 = __VLS_pickFunctionalComponentCtx(__VLS_386, __VLS_388)!;
let __VLS_390!: __VLS_NormalizeEmits<typeof __VLS_389.emit>;
(__VLS_389.slots!).default;
}
{
const __VLS_391 = __VLS_intrinsicElements["div"];
const __VLS_392 = __VLS_elementAsFunctionalComponent(__VLS_391);
const __VLS_393 = __VLS_392({ ...{}, class: ("col-md-9"), }, ...__VLS_functionalComponentArgsRest(__VLS_392));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_391, typeof __VLS_393> & Record<string, unknown>) => void)({ ...{}, class: ("col-md-9"), });
const __VLS_394 = __VLS_pickFunctionalComponentCtx(__VLS_391, __VLS_393)!;
let __VLS_395!: __VLS_NormalizeEmits<typeof __VLS_394.emit>;
{
const __VLS_396 = __VLS_intrinsicElements["select"];
const __VLS_397 = __VLS_elementAsFunctionalComponent(__VLS_396);
const __VLS_398 = __VLS_397({ ...{}, class: ("form-control"), value: ((__VLS_ctx.idcategoria)), }, ...__VLS_functionalComponentArgsRest(__VLS_397));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_396, typeof __VLS_398> & Record<string, unknown>) => void)({ ...{}, class: ("form-control"), value: ((__VLS_ctx.idcategoria)), });
const __VLS_399 = __VLS_pickFunctionalComponentCtx(__VLS_396, __VLS_398)!;
let __VLS_400!: __VLS_NormalizeEmits<typeof __VLS_399.emit>;
{
const __VLS_401 = __VLS_intrinsicElements["option"];
const __VLS_402 = __VLS_elementAsFunctionalComponent(__VLS_401);
const __VLS_403 = __VLS_402({ ...{}, value: ("0"), disabled: (true), }, ...__VLS_functionalComponentArgsRest(__VLS_402));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_401, typeof __VLS_403> & Record<string, unknown>) => void)({ ...{}, value: ("0"), disabled: (true), });
const __VLS_404 = __VLS_pickFunctionalComponentCtx(__VLS_401, __VLS_403)!;
let __VLS_405!: __VLS_NormalizeEmits<typeof __VLS_404.emit>;
(__VLS_404.slots!).default;
}
for (const [categoria] of __VLS_getVForSourceType((__VLS_ctx.arrayCategoria)!)) {
{
const __VLS_406 = __VLS_intrinsicElements["option"];
const __VLS_407 = __VLS_elementAsFunctionalComponent(__VLS_406);
const __VLS_408 = __VLS_407({ ...{}, key: ((categoria.id)), value: ((categoria.id)), }, ...__VLS_functionalComponentArgsRest(__VLS_407));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_406, typeof __VLS_408> & Record<string, unknown>) => void)({ ...{}, key: ((categoria.id)), value: ((categoria.id)), });
const __VLS_409 = __VLS_pickFunctionalComponentCtx(__VLS_406, __VLS_408)!;
let __VLS_410!: __VLS_NormalizeEmits<typeof __VLS_409.emit>;
__VLS_directiveFunction(__VLS_ctx.vText)((categoria.nombre));
}
// @ts-ignore
[idcategoria, idcategoria, arrayCategoria,];
}
(__VLS_399.slots!).default;
}
(__VLS_394.slots!).default;
}
(__VLS_384.slots!).default;
}
{
const __VLS_411 = __VLS_intrinsicElements["div"];
const __VLS_412 = __VLS_elementAsFunctionalComponent(__VLS_411);
const __VLS_413 = __VLS_412({ ...{}, class: ("form-group row"), }, ...__VLS_functionalComponentArgsRest(__VLS_412));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_411, typeof __VLS_413> & Record<string, unknown>) => void)({ ...{}, class: ("form-group row"), });
const __VLS_414 = __VLS_pickFunctionalComponentCtx(__VLS_411, __VLS_413)!;
let __VLS_415!: __VLS_NormalizeEmits<typeof __VLS_414.emit>;
{
const __VLS_416 = __VLS_intrinsicElements["label"];
const __VLS_417 = __VLS_elementAsFunctionalComponent(__VLS_416);
const __VLS_418 = __VLS_417({ ...{}, class: ("col-md-3 form-control-label"), for: ("text-input"), }, ...__VLS_functionalComponentArgsRest(__VLS_417));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_416, typeof __VLS_418> & Record<string, unknown>) => void)({ ...{}, class: ("col-md-3 form-control-label"), for: ("text-input"), });
const __VLS_419 = __VLS_pickFunctionalComponentCtx(__VLS_416, __VLS_418)!;
let __VLS_420!: __VLS_NormalizeEmits<typeof __VLS_419.emit>;
(__VLS_419.slots!).default;
}
{
const __VLS_421 = __VLS_intrinsicElements["div"];
const __VLS_422 = __VLS_elementAsFunctionalComponent(__VLS_421);
const __VLS_423 = __VLS_422({ ...{}, class: ("col-md-9"), }, ...__VLS_functionalComponentArgsRest(__VLS_422));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_421, typeof __VLS_423> & Record<string, unknown>) => void)({ ...{}, class: ("col-md-9"), });
const __VLS_424 = __VLS_pickFunctionalComponentCtx(__VLS_421, __VLS_423)!;
let __VLS_425!: __VLS_NormalizeEmits<typeof __VLS_424.emit>;
{
const __VLS_426 = __VLS_intrinsicElements["input"];
const __VLS_427 = __VLS_elementAsFunctionalComponent(__VLS_426);
const __VLS_428 = __VLS_427({ ...{}, type: ("text"), value: ((__VLS_ctx.codigo)), class: ("form-control"), placeholder: ("Código de barras"), }, ...__VLS_functionalComponentArgsRest(__VLS_427));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_426, typeof __VLS_428> & Record<string, unknown>) => void)({ ...{}, type: ("text"), value: ((__VLS_ctx.codigo)), class: ("form-control"), placeholder: ("Código de barras"), });
const __VLS_429 = __VLS_pickFunctionalComponentCtx(__VLS_426, __VLS_428)!;
let __VLS_430!: __VLS_NormalizeEmits<typeof __VLS_429.emit>;
}
{
let __VLS_431!: 'Barcode' extends keyof typeof __VLS_ctx ? typeof __VLS_ctx.Barcode : 'barcode' extends keyof typeof __VLS_ctx ? typeof __VLS_ctx.barcode : (typeof __VLS_resolvedLocalAndGlobalComponents)['barcode'];
const __VLS_432 = __VLS_asFunctionalComponent(__VLS_431, new __VLS_431({ ...{}, value: ((__VLS_ctx.codigo)), options: (({ format: 'EAN-13' })), }));
({} as { barcode: typeof __VLS_431; }).barcode;
({} as { barcode: typeof __VLS_431; }).barcode;
const __VLS_433 = __VLS_432({ ...{}, value: ((__VLS_ctx.codigo)), options: (({ format: 'EAN-13' })), }, ...__VLS_functionalComponentArgsRest(__VLS_432));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_431, typeof __VLS_433> & Record<string, unknown>) => void)({ ...{}, value: ((__VLS_ctx.codigo)), options: (({ format: 'EAN-13' })), });
const __VLS_434 = __VLS_pickFunctionalComponentCtx(__VLS_431, __VLS_433)!;
let __VLS_435!: __VLS_NormalizeEmits<typeof __VLS_434.emit>;
(__VLS_434.slots!).default;
}
(__VLS_424.slots!).default;
}
(__VLS_414.slots!).default;
}
{
const __VLS_436 = __VLS_intrinsicElements["div"];
const __VLS_437 = __VLS_elementAsFunctionalComponent(__VLS_436);
const __VLS_438 = __VLS_437({ ...{}, class: ("form-group row"), }, ...__VLS_functionalComponentArgsRest(__VLS_437));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_436, typeof __VLS_438> & Record<string, unknown>) => void)({ ...{}, class: ("form-group row"), });
const __VLS_439 = __VLS_pickFunctionalComponentCtx(__VLS_436, __VLS_438)!;
let __VLS_440!: __VLS_NormalizeEmits<typeof __VLS_439.emit>;
{
const __VLS_441 = __VLS_intrinsicElements["label"];
const __VLS_442 = __VLS_elementAsFunctionalComponent(__VLS_441);
const __VLS_443 = __VLS_442({ ...{}, class: ("col-md-3 form-control-label"), for: ("text-input"), }, ...__VLS_functionalComponentArgsRest(__VLS_442));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_441, typeof __VLS_443> & Record<string, unknown>) => void)({ ...{}, class: ("col-md-3 form-control-label"), for: ("text-input"), });
const __VLS_444 = __VLS_pickFunctionalComponentCtx(__VLS_441, __VLS_443)!;
let __VLS_445!: __VLS_NormalizeEmits<typeof __VLS_444.emit>;
(__VLS_444.slots!).default;
}
{
const __VLS_446 = __VLS_intrinsicElements["div"];
const __VLS_447 = __VLS_elementAsFunctionalComponent(__VLS_446);
const __VLS_448 = __VLS_447({ ...{}, class: ("col-md-9"), }, ...__VLS_functionalComponentArgsRest(__VLS_447));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_446, typeof __VLS_448> & Record<string, unknown>) => void)({ ...{}, class: ("col-md-9"), });
const __VLS_449 = __VLS_pickFunctionalComponentCtx(__VLS_446, __VLS_448)!;
let __VLS_450!: __VLS_NormalizeEmits<typeof __VLS_449.emit>;
{
const __VLS_451 = __VLS_intrinsicElements["input"];
const __VLS_452 = __VLS_elementAsFunctionalComponent(__VLS_451);
const __VLS_453 = __VLS_452({ ...{}, type: ("text"), value: ((__VLS_ctx.nombre)), class: ("form-control"), placeholder: ("Nombre de artículo"), }, ...__VLS_functionalComponentArgsRest(__VLS_452));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_451, typeof __VLS_453> & Record<string, unknown>) => void)({ ...{}, type: ("text"), value: ((__VLS_ctx.nombre)), class: ("form-control"), placeholder: ("Nombre de artículo"), });
const __VLS_454 = __VLS_pickFunctionalComponentCtx(__VLS_451, __VLS_453)!;
let __VLS_455!: __VLS_NormalizeEmits<typeof __VLS_454.emit>;
}
(__VLS_449.slots!).default;
}
(__VLS_439.slots!).default;
}
{
const __VLS_456 = __VLS_intrinsicElements["div"];
const __VLS_457 = __VLS_elementAsFunctionalComponent(__VLS_456);
const __VLS_458 = __VLS_457({ ...{}, class: ("form-group row"), }, ...__VLS_functionalComponentArgsRest(__VLS_457));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_456, typeof __VLS_458> & Record<string, unknown>) => void)({ ...{}, class: ("form-group row"), });
const __VLS_459 = __VLS_pickFunctionalComponentCtx(__VLS_456, __VLS_458)!;
let __VLS_460!: __VLS_NormalizeEmits<typeof __VLS_459.emit>;
{
const __VLS_461 = __VLS_intrinsicElements["label"];
const __VLS_462 = __VLS_elementAsFunctionalComponent(__VLS_461);
const __VLS_463 = __VLS_462({ ...{}, class: ("col-md-3 form-control-label"), for: ("text-input"), }, ...__VLS_functionalComponentArgsRest(__VLS_462));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_461, typeof __VLS_463> & Record<string, unknown>) => void)({ ...{}, class: ("col-md-3 form-control-label"), for: ("text-input"), });
const __VLS_464 = __VLS_pickFunctionalComponentCtx(__VLS_461, __VLS_463)!;
let __VLS_465!: __VLS_NormalizeEmits<typeof __VLS_464.emit>;
(__VLS_464.slots!).default;
}
{
const __VLS_466 = __VLS_intrinsicElements["div"];
const __VLS_467 = __VLS_elementAsFunctionalComponent(__VLS_466);
const __VLS_468 = __VLS_467({ ...{}, class: ("col-md-9"), }, ...__VLS_functionalComponentArgsRest(__VLS_467));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_466, typeof __VLS_468> & Record<string, unknown>) => void)({ ...{}, class: ("col-md-9"), });
const __VLS_469 = __VLS_pickFunctionalComponentCtx(__VLS_466, __VLS_468)!;
let __VLS_470!: __VLS_NormalizeEmits<typeof __VLS_469.emit>;
{
const __VLS_471 = __VLS_intrinsicElements["input"];
const __VLS_472 = __VLS_elementAsFunctionalComponent(__VLS_471);
const __VLS_473 = __VLS_472({ ...{}, type: ("number"), class: ("form-control"), placeholder: (""), }, ...__VLS_functionalComponentArgsRest(__VLS_472));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_471, typeof __VLS_473> & Record<string, unknown>) => void)({ ...{}, type: ("number"), class: ("form-control"), placeholder: (""), });
const __VLS_474 = __VLS_pickFunctionalComponentCtx(__VLS_471, __VLS_473)!;
let __VLS_475!: __VLS_NormalizeEmits<typeof __VLS_474.emit>;
(__VLS_ctx.precio_venta);
}
(__VLS_469.slots!).default;
}
(__VLS_459.slots!).default;
}
{
const __VLS_476 = __VLS_intrinsicElements["div"];
const __VLS_477 = __VLS_elementAsFunctionalComponent(__VLS_476);
const __VLS_478 = __VLS_477({ ...{}, class: ("form-group row"), }, ...__VLS_functionalComponentArgsRest(__VLS_477));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_476, typeof __VLS_478> & Record<string, unknown>) => void)({ ...{}, class: ("form-group row"), });
const __VLS_479 = __VLS_pickFunctionalComponentCtx(__VLS_476, __VLS_478)!;
let __VLS_480!: __VLS_NormalizeEmits<typeof __VLS_479.emit>;
{
const __VLS_481 = __VLS_intrinsicElements["label"];
const __VLS_482 = __VLS_elementAsFunctionalComponent(__VLS_481);
const __VLS_483 = __VLS_482({ ...{}, class: ("col-md-3 form-control-label"), for: ("text-input"), }, ...__VLS_functionalComponentArgsRest(__VLS_482));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_481, typeof __VLS_483> & Record<string, unknown>) => void)({ ...{}, class: ("col-md-3 form-control-label"), for: ("text-input"), });
const __VLS_484 = __VLS_pickFunctionalComponentCtx(__VLS_481, __VLS_483)!;
let __VLS_485!: __VLS_NormalizeEmits<typeof __VLS_484.emit>;
(__VLS_484.slots!).default;
}
{
const __VLS_486 = __VLS_intrinsicElements["div"];
const __VLS_487 = __VLS_elementAsFunctionalComponent(__VLS_486);
const __VLS_488 = __VLS_487({ ...{}, class: ("col-md-9"), }, ...__VLS_functionalComponentArgsRest(__VLS_487));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_486, typeof __VLS_488> & Record<string, unknown>) => void)({ ...{}, class: ("col-md-9"), });
const __VLS_489 = __VLS_pickFunctionalComponentCtx(__VLS_486, __VLS_488)!;
let __VLS_490!: __VLS_NormalizeEmits<typeof __VLS_489.emit>;
{
const __VLS_491 = __VLS_intrinsicElements["input"];
const __VLS_492 = __VLS_elementAsFunctionalComponent(__VLS_491);
const __VLS_493 = __VLS_492({ ...{}, type: ("number"), class: ("form-control"), placeholder: (""), }, ...__VLS_functionalComponentArgsRest(__VLS_492));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_491, typeof __VLS_493> & Record<string, unknown>) => void)({ ...{}, type: ("number"), class: ("form-control"), placeholder: (""), });
const __VLS_494 = __VLS_pickFunctionalComponentCtx(__VLS_491, __VLS_493)!;
let __VLS_495!: __VLS_NormalizeEmits<typeof __VLS_494.emit>;
(__VLS_ctx.stock);
}
(__VLS_489.slots!).default;
}
(__VLS_479.slots!).default;
}
{
const __VLS_496 = __VLS_intrinsicElements["div"];
const __VLS_497 = __VLS_elementAsFunctionalComponent(__VLS_496);
const __VLS_498 = __VLS_497({ ...{}, class: ("form-group row"), }, ...__VLS_functionalComponentArgsRest(__VLS_497));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_496, typeof __VLS_498> & Record<string, unknown>) => void)({ ...{}, class: ("form-group row"), });
const __VLS_499 = __VLS_pickFunctionalComponentCtx(__VLS_496, __VLS_498)!;
let __VLS_500!: __VLS_NormalizeEmits<typeof __VLS_499.emit>;
{
const __VLS_501 = __VLS_intrinsicElements["label"];
const __VLS_502 = __VLS_elementAsFunctionalComponent(__VLS_501);
const __VLS_503 = __VLS_502({ ...{}, class: ("col-md-3 form-control-label"), for: ("email-input"), }, ...__VLS_functionalComponentArgsRest(__VLS_502));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_501, typeof __VLS_503> & Record<string, unknown>) => void)({ ...{}, class: ("col-md-3 form-control-label"), for: ("email-input"), });
const __VLS_504 = __VLS_pickFunctionalComponentCtx(__VLS_501, __VLS_503)!;
let __VLS_505!: __VLS_NormalizeEmits<typeof __VLS_504.emit>;
(__VLS_504.slots!).default;
}
{
const __VLS_506 = __VLS_intrinsicElements["div"];
const __VLS_507 = __VLS_elementAsFunctionalComponent(__VLS_506);
const __VLS_508 = __VLS_507({ ...{}, class: ("col-md-9"), }, ...__VLS_functionalComponentArgsRest(__VLS_507));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_506, typeof __VLS_508> & Record<string, unknown>) => void)({ ...{}, class: ("col-md-9"), });
const __VLS_509 = __VLS_pickFunctionalComponentCtx(__VLS_506, __VLS_508)!;
let __VLS_510!: __VLS_NormalizeEmits<typeof __VLS_509.emit>;
{
const __VLS_511 = __VLS_intrinsicElements["input"];
const __VLS_512 = __VLS_elementAsFunctionalComponent(__VLS_511);
const __VLS_513 = __VLS_512({ ...{}, type: ("email"), class: ("form-control"), placeholder: ("Ingrese descripción"), }, ...__VLS_functionalComponentArgsRest(__VLS_512));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_511, typeof __VLS_513> & Record<string, unknown>) => void)({ ...{}, type: ("email"), class: ("form-control"), placeholder: ("Ingrese descripción"), });
const __VLS_514 = __VLS_pickFunctionalComponentCtx(__VLS_511, __VLS_513)!;
let __VLS_515!: __VLS_NormalizeEmits<typeof __VLS_514.emit>;
(__VLS_ctx.descripcion);
}
(__VLS_509.slots!).default;
}
(__VLS_499.slots!).default;
}
{
const __VLS_516 = __VLS_intrinsicElements["div"];
const __VLS_517 = __VLS_elementAsFunctionalComponent(__VLS_516);
const __VLS_518 = __VLS_517({ ...{}, class: ("form-group row div-error"), }, ...__VLS_functionalComponentArgsRest(__VLS_517));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_516, typeof __VLS_518> & Record<string, unknown>) => void)({ ...{}, class: ("form-group row div-error"), });
const __VLS_519 = __VLS_pickFunctionalComponentCtx(__VLS_516, __VLS_518)!;
let __VLS_520!: __VLS_NormalizeEmits<typeof __VLS_519.emit>;
__VLS_directiveFunction(__VLS_ctx.vShow)((__VLS_ctx.errorArticulo));
{
const __VLS_521 = __VLS_intrinsicElements["div"];
const __VLS_522 = __VLS_elementAsFunctionalComponent(__VLS_521);
const __VLS_523 = __VLS_522({ ...{}, class: ("text-center text-error"), }, ...__VLS_functionalComponentArgsRest(__VLS_522));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_521, typeof __VLS_523> & Record<string, unknown>) => void)({ ...{}, class: ("text-center text-error"), });
const __VLS_524 = __VLS_pickFunctionalComponentCtx(__VLS_521, __VLS_523)!;
let __VLS_525!: __VLS_NormalizeEmits<typeof __VLS_524.emit>;
for (const [error] of __VLS_getVForSourceType((__VLS_ctx.errorMostrarMsjArticulo)!)) {
{
const __VLS_526 = __VLS_intrinsicElements["div"];
const __VLS_527 = __VLS_elementAsFunctionalComponent(__VLS_526);
const __VLS_528 = __VLS_527({ ...{}, key: ((error)), }, ...__VLS_functionalComponentArgsRest(__VLS_527));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_526, typeof __VLS_528> & Record<string, unknown>) => void)({ ...{}, key: ((error)), });
const __VLS_529 = __VLS_pickFunctionalComponentCtx(__VLS_526, __VLS_528)!;
let __VLS_530!: __VLS_NormalizeEmits<typeof __VLS_529.emit>;
__VLS_directiveFunction(__VLS_ctx.vText)((error));
}
// @ts-ignore
[codigo, codigo, codigo, codigo, codigo, nombre, nombre, precio_venta, stock, descripcion, errorArticulo, errorMostrarMsjArticulo,];
}
(__VLS_524.slots!).default;
}
(__VLS_519.slots!).default;
}
(__VLS_379.slots!).default;
}
(__VLS_374.slots!).default;
}
{
const __VLS_531 = __VLS_intrinsicElements["div"];
const __VLS_532 = __VLS_elementAsFunctionalComponent(__VLS_531);
const __VLS_533 = __VLS_532({ ...{}, class: ("modal-footer"), }, ...__VLS_functionalComponentArgsRest(__VLS_532));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_531, typeof __VLS_533> & Record<string, unknown>) => void)({ ...{}, class: ("modal-footer"), });
const __VLS_534 = __VLS_pickFunctionalComponentCtx(__VLS_531, __VLS_533)!;
let __VLS_535!: __VLS_NormalizeEmits<typeof __VLS_534.emit>;
{
const __VLS_536 = __VLS_intrinsicElements["button"];
const __VLS_537 = __VLS_elementAsFunctionalComponent(__VLS_536);
const __VLS_538 = __VLS_537({ ...{ onClick: {} as any, }, type: ("button"), class: ("btn btn-secondary"), }, ...__VLS_functionalComponentArgsRest(__VLS_537));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_536, typeof __VLS_538> & Record<string, unknown>) => void)({ ...{ onClick: {} as any, }, type: ("button"), class: ("btn btn-secondary"), });
const __VLS_539 = __VLS_pickFunctionalComponentCtx(__VLS_536, __VLS_538)!;
let __VLS_540!: __VLS_NormalizeEmits<typeof __VLS_539.emit>;
let __VLS_541 = { 'click': __VLS_pickEvent(__VLS_540['click'], ({} as __VLS_FunctionalComponentProps<typeof __VLS_537, typeof __VLS_538>).onClick) };
__VLS_541 = {
click: $event => {
__VLS_ctx.cerrarModal();
// @ts-ignore
[cerrarModal,];
}
};
(__VLS_539.slots!).default;
}
if (__VLS_ctx.tipoAccion == 1) {
{
const __VLS_542 = __VLS_intrinsicElements["button"];
const __VLS_543 = __VLS_elementAsFunctionalComponent(__VLS_542);
const __VLS_544 = __VLS_543({ ...{ onClick: {} as any, }, type: ("button"), class: ("btn btn-primary"), }, ...__VLS_functionalComponentArgsRest(__VLS_543));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_542, typeof __VLS_544> & Record<string, unknown>) => void)({ ...{ onClick: {} as any, }, type: ("button"), class: ("btn btn-primary"), });
const __VLS_545 = __VLS_pickFunctionalComponentCtx(__VLS_542, __VLS_544)!;
let __VLS_546!: __VLS_NormalizeEmits<typeof __VLS_545.emit>;
let __VLS_547 = { 'click': __VLS_pickEvent(__VLS_546['click'], ({} as __VLS_FunctionalComponentProps<typeof __VLS_543, typeof __VLS_544>).onClick) };
__VLS_547 = {
click: $event => {
if (!((__VLS_ctx.tipoAccion == 1))) return;
__VLS_ctx.registrarArticulo();
// @ts-ignore
[tipoAccion, registrarArticulo,];
}
};
(__VLS_545.slots!).default;
}
}
if (__VLS_ctx.tipoAccion == 2) {
{
const __VLS_548 = __VLS_intrinsicElements["button"];
const __VLS_549 = __VLS_elementAsFunctionalComponent(__VLS_548);
const __VLS_550 = __VLS_549({ ...{ onClick: {} as any, }, type: ("button"), class: ("btn btn-primary"), }, ...__VLS_functionalComponentArgsRest(__VLS_549));
({} as (props: __VLS_FunctionalComponentProps<typeof __VLS_548, typeof __VLS_550> & Record<string, unknown>) => void)({ ...{ onClick: {} as any, }, type: ("button"), class: ("btn btn-primary"), });
const __VLS_551 = __VLS_pickFunctionalComponentCtx(__VLS_548, __VLS_550)!;
let __VLS_552!: __VLS_NormalizeEmits<typeof __VLS_551.emit>;
let __VLS_553 = { 'click': __VLS_pickEvent(__VLS_552['click'], ({} as __VLS_FunctionalComponentProps<typeof __VLS_549, typeof __VLS_550>).onClick) };
__VLS_553 = {
click: $event => {
if (!((__VLS_ctx.tipoAccion == 2))) return;
__VLS_ctx.actualizarArticulo();
// @ts-ignore
[tipoAccion, actualizarArticulo,];
}
};
(__VLS_551.slots!).default;
}
}
(__VLS_534.slots!).default;
}
(__VLS_348.slots!).default;
}
(__VLS_343.slots!).default;
}
(__VLS_338.slots!).default;
}
if (typeof __VLS_styleScopedClasses === 'object' && !Array.isArray(__VLS_styleScopedClasses)) {
}
var __VLS_slots!: {};
return __VLS_slots;
}
