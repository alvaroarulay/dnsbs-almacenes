<template>
    <main class="app-content">
    <div class="app-title">
        <div>
          <h1><i class="bi bi-laptop"></i> Almacen:</h1>
        </div>
    </div>
    <template v-if="!newpedido">
         <div class="tile">
            <h3 class="tile-title">Pedidos</h3>
            <div class="text-left mb-3">
                <button class="btn btn-primary" @click="abrirNuevoPedido">
                    <i class="bi bi-plus"></i>Nuevo</button>
            </div>
            <div class="row mb-3">
                <div class="text-left col-md-6">
                    <button class="btn btn-success btn-sm"><i class="bi bi-file-earmark-excel"></i></button>
                    <button class="btn btn-danger btn-sm"><i class="bi bi-file-earmark-pdf"></i></button>
                    <button class="btn btn-info btn-sm"><i class="bi bi-printer"></i></button>
                </div>
                <div class="text-end col-md-6">
                     <div class="input-group mb-3 ">
                        <span class="input-group-text" id="almacen"><i class="bi bi-search"></i></span>
                        <input type="text" class="form-control" aria-describedby="almacen" >
                        <button class="btn btn-info btn-sm">Buscar</button>
                    </div>
                </div>
            </div>
            <div class="tile-body">
                <div class="table-responsive">
                   <table class="table">
                        <thead class="thead-dark">
                            <tr>
                                <th>Código</th>
                                <th>Descripción</th>
                                <th>Precio Unitario</th>
                                <th>Precio Final</th>
                                <th>Stock Actual</th>
                                <th>Stock Minimo</th>
                                <th>Grupo</th>
                                <th>Unidad</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td>1</td>
                            <td>Mark</td>
                            <td>Otto</td>
                            <td>@mdo</td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Jacob</td>
                            <td>Thornton</td>
                            <td>@fat</td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>Larry</td>
                            <td>the Bird</td>
                            <td>@twitter</td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td>Jacob</td>
                            <td>Thornton</td>
                            <td>@fat</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </template>
    <template v-else-if="newpedido">
          <div class="row">
        <div class="col-md-6">
            <div class="card border-primary mb-3">
                <div class="card-header text-bg-primary mb-3">Articulos</div>

                <div class="card-body text-primary">
                    <div class="row mb-3">
                        <div class="col-md-6">
                          <label for="articulos" class="form-label">Busqueda</label>
                          <div class="input-group">
                            <span class="input-group-text" id="almacen"><i class="bi bi-search"></i></span>
                            <input type="text" class="form-control" aria-describedby="almacen" >
                            <button class="btn btn-info btn-sm">Buscar</button>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <label for="" class="form-label">Código</label>
                          <div class="input-group">
                            <span class="input-group-text" id="codigo"><i class="bi bi-upc"></i></span>
                            <input type="text" class="form-control" aria-describedby="codigo" >
                          </div>
                        </div>
                    </div>
                    <div class="row">
                        <label for="" class="form-label">Descripción</label>
                        <div class="input-group mb-3 ">
                            <span class="input-group-text" id="descripcion"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-alphabet-uppercase" viewBox="0 0 16 16">
                              <path d="M1.226 10.88H0l2.056-6.26h1.42l2.047 6.26h-1.29l-.48-1.61H1.707l-.48 1.61ZM2.76 5.818h-.054l-.75 2.532H3.51zm3.217 5.062V4.62h2.56c1.09 0 1.808.582 1.808 1.54 0 .762-.444 1.22-1.05 1.372v.055c.736.074 1.365.587 1.365 1.528 0 1.119-.89 1.766-2.133 1.766zM7.18 5.55v1.675h.8c.812 0 1.171-.308 1.171-.853 0-.51-.328-.822-.898-.822zm0 2.537V9.95h.903c.951 0 1.342-.312 1.342-.909 0-.591-.382-.954-1.095-.954zm5.089-.711v.775c0 1.156.49 1.803 1.347 1.803.705 0 1.163-.454 1.212-1.096H16v.12C15.942 10.173 14.95 11 13.607 11c-1.648 0-2.573-1.073-2.573-2.849v-.78c0-1.775.934-2.871 2.573-2.871 1.347 0 2.34.849 2.393 2.087v.115h-1.172c-.05-.665-.516-1.156-1.212-1.156-.849 0-1.347.67-1.347 1.83"/>
                            </svg></span>
                            <input type="text" class="form-control" aria-describedby="descripcion" >
                        </div>
                    </div>
                     <div class="row mb-3">
                        <div class="col-md-6">
                          <label for="articulos" class="form-label">Precio de Pedido</label>
                          <div class="input-group">
                            <span class="input-group-text" id="precio"><i class="bi bi-currency-dollar"></i></span>
                            <input type="text" class="form-control" aria-describedby="precio" >
                          </div>
                        </div>
                        <div class="col-md-6">
                          <label for="" class="form-label">Stock</label>
                          <div class="input-group">
                            <span class="input-group-text" id="stock"><i class="bi bi-hash"></i></span>
                            <input type="text" class="form-control" aria-describedby="stock" >
                          </div>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                          <label for="articulos" class="form-label">Unidad de Medida</label>
                          <div class="input-group">
                            <span class="input-group-text" id="unidad"><i class="bi bi-rulers"></i></span>
                            <input type="text" class="form-control" aria-describedby="unidad" >
                          </div>
                        </div>
                        <div class="col-md-6">
                          <label for="" class="form-label">Cantidad</label>
                          <div class="input-group">
                            <span class="input-group-text" id="cantidad"><i class="bi bi-hash"></i></span>
                            <input type="text" class="form-control" aria-describedby="cantidad" >
                          </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-center d-grid gap-2 d-md-flex justify-content-md-end">
                    <button class="btn btn-primary" type="button"><i class="bi bi-plus-circle-fill me-2"></i>Agregar</button>
                    <button class="btn btn-danger" @click="cerrarNuevoPedido"><i class="bi bi-x-circle-fill me-2"></i>Cancelar</button>
                 </div>
            </div>
        </div>
        <div class="col-md-6">
          <div class="card border-info mb-3">
                <div class="card-header text-bg-info mb-3">Pedido</div>

                <div class="card-body text-primary">
                   <div class="row mb-3">
                        <div class="input-group input-group-lg">
                          <div class="input-group-prepend">
                            <span class="input-group-text" id="inputGroup-sizing-lg"><svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-currency-dollar" viewBox="0 0 16 16">
                              <path d="M4 10.781c.148 1.667 1.513 2.85 3.591 3.003V15h1.043v-1.216c2.27-.179 3.678-1.438 3.678-3.3 0-1.59-.947-2.51-2.956-3.028l-.722-.187V3.467c1.122.11 1.879.714 2.07 1.616h1.47c-.166-1.6-1.54-2.748-3.54-2.875V1H7.591v1.233c-1.939.23-3.27 1.472-3.27 3.156 0 1.454.966 2.483 2.661 2.917l.61.162v4.031c-1.149-.17-1.94-.8-2.131-1.718zm3.391-3.836c-1.043-.263-1.6-.825-1.6-1.616 0-.944.704-1.641 1.8-1.828v3.495l-.2-.05zm1.591 1.872c1.287.323 1.852.859 1.852 1.769 0 1.097-.826 1.828-2.2 1.939V8.73z"/>
                            </svg></span>
                          </div>
                          <input type="text" class="form-control bg-warning text-center" aria-label="Large" aria-describedby="inputGroup-sizing-sm">
                        </div>
                    </div>
                     <div class="row mb-4">
                        <div class="col-md-6">
                          <label for="articulos" class="form-label">Nº de Pedido</label>
                          <div class="input-group">
                            <span class="input-group-text" id="precio"><i class="bi bi-hash"></i></span>
                            <input type="text" class="form-control bg-warning" aria-describedby="precio" >
                          </div>
                        </div>
                        <div class="col-md-6">
                          <label for="" class="form-label">fecha</label>
                          <div class="input-group">
                            <span class="input-group-text" id="stock"><i class="bi bi-calendar-date"></i></span>
                            <input type="date" class="form-control" aria-describedby="stock" >
                          </div>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-6">
                          <label for="person" class="form-label">Personal</label>
                          <div class="input-group">
                            <span class="input-group-text" id="person"><i class="bi bi-search"></i></span>
                            <input type="text" class="form-control" aria-describedby="person" placeholder="ingrese ci">
                            <button class="btn btn-info btn-sm">Buscar</button>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <label for="" class="form-label">Carnet de Identidad</label>
                          <div class="input-group">
                            <span class="input-group-text" id="cantidad"><i class="bi bi-hash"></i></span>
                            <input type="text" class="form-control" aria-describedby="cantidad" >
                          </div>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="" class="form-label">Nombre</label>
                        <div class="input-group ">
                            <span class="input-group-text" id="name"><i class="bi bi-person"></i></span>
                            <input type="text" class="form-control" aria-describedby="name" >
                        </div>
                    </div>
                </div>
                <div class="card-footer text-center d-grid gap-2 d-md-flex justify-content-md-end">
                    <button class="btn btn-info" type="button"><i class="bi bi-check"></i>Confirmar</button>
                 </div>
            </div>
        </div>
        <div class="clearix"></div>
        <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title">Detalle</h3>
            <div class="tile-body">
                <div class="table-responsive">
                   <table class="table">
                        <thead class="thead-dark">
                            <tr>
                                <th>Código</th>
                                <th>Descripción</th>
                                <th>Cantidad</th>
                                <th>Precio Unitario</th>
                                <th>Precio Final</th>
                                <th>Total</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td>1</td>
                            <td>Mark</td>
                            <td>Otto</td>
                            <td>@mdo</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
          </div>
        </div>
      </div>
      
    </template> 
    </main>
</template>
<script setup>
import { ref, onMounted } from 'vue';
import axios from 'axios';
const newpedido = ref(false);

function abrirNuevoPedido() {
    newpedido.value = true;
};
function cerrarNuevoPedido() {
    newpedido.value = false;
}
</script>