@extends('layouts.error')
<div class="page-error">
    <h1 class="text-danger"><i class="bi bi-exclamation-circle"></i> Error 500: Un Error a Ocurrido</h1>
    <p>Ocurrio un error en el servidor, por favor reintentalo.</p>
    <p><a class="btn btn-primary" href="javascript:window.history.back();">Atrás</a></p>
</div>