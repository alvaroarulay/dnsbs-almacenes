<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy;
                 <a href="https://selabi.principalwebsite.com" target="__blank">Selabí 2023</a></div>
            <div>
            </div>
        </div>
    </div>
</footer>