

<html>
<head>
	<style>
	@page {
		margin: 0cm 0cm;
	}
	body{
		font-family: 'arial', sans-serif;
		margin-top: 3.5cm;
		margin-left: 1cm;
		margin-right: 1cm;
		margin-bottom: 1cm;
		width: 29.5cm;
	}
	hr{
		margin: 0;
		border-top: 1px solid rgb(0, 0, 0);
	}
	#customers {
		border-collapse: collapse;
		font-size: 7pt;
	}
	#customers td, #customers th {
		padding: 5px;
		border: 1px solid #000;
	}
	#customers th {
		text-align: center;
		background-color: #ddd;
		color: black;
	}
	#customers thead { display: table-header-group; }
	.eslogan{
		font-size: xx-small;
		font-style: italic;
	}
	#cabecera tr td{
		margin:0;
		padding:0;
		font-size: 6pt;
	}
	header {
		position: fixed;
		top: 1cm;
		left: 1cm;
		right: 1cm;
		height: 3cm;
		}
	footer {
		position: relative;
		left: 1cm;
		right: 0cm;
	}
	.page-break {
	    page-break-after: always;
	}
</style>
</head>
<body>
	<header>
		<div style="width: 33cm; height: 2.2cm;">
		<table>
			<tr>
				<td>
					<div style="width: 7cm; height: 2.5cm; text-align: center;">
						<img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="" style="width: auto; height: 1.5cm; ">
					</div>
				</td>
				<td>
					<div style="width: 15cm; height: 2cm;">
					<p style="margin-top: 0.5cm; text-align: center;" ><b>ACTA DE INVENTARIO Y ASIGNACIÓN DE BIENES</b></p>
					<p style="font-size: xx-small; margin: 0; text-align: center;"><?php echo e($responsable->ciudad. ', ' .$fechaTitulo); ?></p>
				</div>
				</td>
				<td>
					<div style="width: 5cm; height: 1cm; ">
						<p style="font-size: xx-small; margin: 0.1cm; text-align: right;"><b>Página:</b></p>
						
					</div>
				</td>
				<td>
					<div style="width: 2cm; height: 1cm;">
						<p style="font-size: xx-small; margin: 0.1cm;"><br></p>
					</div>
				</td>
			</tr>
		</table>
	</div>
	<hr>
	</header>
	<main>
		<table id="cabecera">
			<tr style=" height: .5cm;">
				<td >
					<p style="font-size: x-small; margin: 0.1cm; text-align: right;"><b>DIRECCIÓN:</b></p>
				</td>
				<td style=" height: .5cm; width:12cm;">
					<!--<p style="font-size: x-small; margin: 0.1cm;">UNIDAD DE AUDITORIA INTERNA</p>!-->
					<p style="font-size: x-small; margin: 0.1cm;"><?php echo e($responsable->direccion); ?></p>
				</td>
				<td>
				<p style="font-size: x-small;  margin: 0.1cm;"><b>UNIDAD/AREA:</b></p>
				</td>
				<td>
				<p style="font-size: x-small;  margin: 0.1cm;"><?php echo e($responsable->oficina); ?></p>
				<!--<p style="font-size: x-small;  margin: 0.1cm;">: ADMINISTRACIÓN Y DE REGISTRO</p>
				</td>!-->
			</tr>
			<tr style=" height: .5cm;">
				<td >
				<p style="font-size: x-small; margin: 0.1cm; text-align: right;"><b>RESPONSABLE:</b></p>
				</td>
				<td >
				<p style="font-size: x-small; margin: 0.1cm;"><?php echo e($responsable->NOMBRE); ?></p>
				</td>
				<td><div style="width: 3cm;  height: .5cm; text-align: right; font-size: x-small; margin: 0.1cm;">C.I.</div></td>
				<td><div style="width: 2cm;  height: .5cm; font-size: x-small; margin: 0.1cm; "><?php echo e($responsable->CI); ?></div> </td>
			</tr>
			<tr style=" height: .5cm;" >
				<td>
				<p style="font-size: x-small; margin: 0.1cm; text-align: right;"><b>CARGO/PUESTO:</b></p>
				</td>
				<td colspan="3">
				
				<p style="font-size: x-small; margin: 0.1cm;"><?php echo e($responsable->CARGO); ?></p>
				</td>
			</tr>
			<tr style=" height: .5cm;">
				<td>
				<p style="font-size: x-small; margin: 0.1cm; text-align: right;"><b>EDIFICIO/INMUEBLE:</b></p>
				</td>
				<td>
				<!--	<p style="font-size: x-small; margin: 0.1cm;">LITORAL - EX-ALUBOL - CENTRAL - WARA WARA </p></td>!-->
				<?php $__currentLoopData = $edificios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edificio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<p style="font-size: x-small; margin: 0.1cm;"><?php echo e($edificio->EDIFICIO.' '); ?></p>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			</tr>
		</table>
		<table id="customers">
			<thead>
				<tr style="border: 1px solid ;">
					<th style="width: 0.5cm;">NRO.</th>
					<th style="width: 2cm;">CÓDIGO</th>
					<th style="width: 2.5cm;">CÓDIGO ANTERIOR</th>
					<th style="width: 3cm;">OTROS CÓDIGOS</th>
					<th style="width: 3cm;">AUXILIAR</th>
					<th style="width: 8cm;">DESCRIPCIÓN</th>
					<th style="width: 2cm;">ESTADO</th>
					<th style="width: 6cm;">UBICACIÓN</th>
					<th style="width: 2cm;">OBSERVACIONES</th>
				</tr>
			</thead>
			<tbody>
				<?php
              $contador = 1;
				?>
				<?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td style="text-align: center;"><?php echo e($contador++); ?></td>
					<td style="text-align: center;"><?php echo e($dato['codigo']); ?></td>
					<td style="text-align: center;"><?php echo e($dato['codanterior']); ?></td>
					<td style="text-align: center;"><?php echo e($dato['otroscodigos']); ?></td>
					<td style="text-align: center;"><?php echo e($dato['auxiliar']); ?></td>
					<td><?php echo e($dato['descripcion']); ?></td>
					<td style="text-align: center;"><?php echo e($dato['estado']); ?></td>
					<td><?php echo e($dato['ubicacion']); ?></td>
					<td><?php echo e($dato['observ']); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
			<tfoot>
				<tr style="border: 1px solid;" >
					<th style="font-size: x-small; text-align: right;" colspan="9" ><b>Cantidad: </b><?php echo e($total); ?></th>
				</tr>
			</tfoot>
		</table>
	</main>
	<footer>
		<table>
			<tr>
				<td style="height: 4cm;">
					<div style=" text-align: center; width: 6cm;">
						<p style="margin: 0.1cm; text-align: center;">___________________</p>
						<!--<p style="font-size: x-small; margin: 0.1cm;">Daniel Ignacio Rios Vargas</p>!-->
						<p style="font-size: x-small; margin: 0.1cm;"><b>Inventariador</b></p>
					</div>
				</td>
				<td style="height: 4cm;">
					<div style=" text-align: center; width: 6cm;">
						<p style="margin: 0.1cm; text-align: center;">___________________</p>
						<p style="font-size: x-small; margin: 0.1cm;">Carolina Beatriz Ortega Miranda</p>
						<p style="font-size: x-small; margin: 0.1cm;"><b>Supervisor Arpro</b></p>
					</div>
				</td>
				<td style="height: 4cm;">
					<div style=" text-align: center; width: 6cm;">
						<p style="margin: 0.1cm; text-align: center;">___________________</p>
						<p style="font-size: x-small; margin: 0.1cm;"><b>Activos Fijos</b></p>
					</div>
				</td>
				<td style="height: 4cm;">
					<div style=" text-align: center; width: 6cm;">
						<p style="margin: 0.1cm; text-align: center;">___________________</p>
						<p style="font-size: x-small; margin: 0.1cm;"><b>VoBo</b></p>
					</div>
				</td>
				<td style="height: 4cm;">
					<div style=" text-align: center; width: 6cm;">
						<p style="margin: 0.1cm; text-align: center;">___________________</p>
						<p style="font-size: x-small; margin: 0.1cm;"><b>Servidor Público</b></p>
					</div>
				</td>
			</tr>
			<tr>
				<td colspan="5" style="text-align:right; font-size: 0.2cm;">Arpro ©</td>
			</tr>
		</table>
	</footer>
	<script type="text/php">
		if ( isset($pdf) ) {
			$pdf->page_script('
				$font = $fontMetrics->get_font("Arial, Helvetica, sans-serif", "NORMAL");
				$pdf->text(805, 52, "$PAGE_NUM de $PAGE_COUNT", $font, 7);
			');
		}
	</script>
</body>
</html><?php /**PATH C:\laragon\www\senape\resources\views/plantillapdf/repAsignacion.blade.php ENDPATH**/ ?>