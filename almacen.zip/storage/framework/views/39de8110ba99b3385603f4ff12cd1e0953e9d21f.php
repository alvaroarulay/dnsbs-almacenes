
<div class="page-error">
    <h1 class="text-danger"><i class="bi bi-exclamation-circle"></i> Error 404: Página no Encontrada</h1>
    <p>La Página que intentas abrir no se encuentra.</p>
    <p><a class="btn btn-primary" href="javascript:window.history.back();">Atrás</a></p>
</div>
<?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventory\resources\views/errors/404.blade.php ENDPATH**/ ?>