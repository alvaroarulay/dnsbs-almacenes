
<div class="page-error">
    <h1 class="text-danger"><i class="bi bi-exclamation-circle"></i> Error 419: Sesión Terminada</h1>
    <p>La Página no se abrirá, sino inicias sesión.</p>
    <p><a class="btn btn-primary" href="<?php echo e(route('login.show')); ?>">Iniciar Sesión</a></p>
</div>
<?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\almacenes\resources\views/errors/419.blade.php ENDPATH**/ ?>