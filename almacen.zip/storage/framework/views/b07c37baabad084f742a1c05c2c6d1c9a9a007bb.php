

<html>
<head>
	<style>
	@page {
		margin: 0cm 0cm;
	}
	body{
		font-family: 'tahoma', sans-serif;
		margin-top: 3.5cm;
		margin-left: 0.7cm;
		margin-right: 0.7cm;
		margin-bottom: 1cm;
		width: 29.5cm;
	}
	hr{
		margin: 0;
		border-top: 1px solid rgb(0, 0, 0);
	}
	#customers {
		border-collapse: collapse;
		font-size: 7pt;
	}
	#customers td, #customers th {
		padding: 5px;
		border: 1px solid #000;
	}
	#customers th {
		text-align: left;
		background-color: #ddd;
		color: black;
	}
	#customers thead { display: table-header-group; }
	.eslogan{
		font-size: xx-small;
		font-style: italic;
	}
	#cabecera tr td{
		margin:0;
		padding:0;
		font-size: 6pt;
	}
	header {
		position: fixed;
		top: 1cm;
		left: 1cm;
		right: 1cm;
		height: 3cm;
		}
	footer {
		position: fixed;
		bottom: 0cm;
		left: 1.5cm;
		right: 0cm;
		height: 2cm;
	}
	.page-break {
	    page-break-after: always;
	}
</style>
</head>
<body>
	<header>
		<div style="width: 33cm; height: 2.2cm;">
		<table>
			<tr>
				<td>
					<div style="width: 4cm; height: 2.5cm; text-align: center;">
						<img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="" style="width: auto; height: 1.5cm; ">
					</div>
				</td>
				<td>
					<div style="width: 18cm; height: 2cm;">
					<p style="margin-top: 0.5cm; text-align: center;" ><b><?php echo e($titulo); ?></b></p>
					
				</div>
				</td>
				<td>
					<div style="width: 4cm; height: 2.5cm; text-align: right; font-size: 6pt;">
						<b>
						<p>
						ARPRO - AVALÚOS Y REVALUOS PROFESIONALES
						</p>
						<p>
							GESTIÓN 2024
						</p>
						<p>
							PRODUCTO Nº 2 - INFORME DE INVENTARIO AL 100%
						</p>	
						</b>
						
					</div>
					
				</td>
				<td>
					<div style="width: 4cm; height: 2.5cm; text-align: center;">
						<img src="<?php echo e(asset('img/arpro.jpg')); ?>" style="width: auto; height: 2cm; ">
					</div>
				</td>
			</tr>
		</table>
	</div>
	</header>
	<main>
		<table id="customers">
			<thead>
				<tr style="border: 1px solid">
					<th style="width: 1cm; text-align:center;">NRO.</th>
					<th style="width: 1.5cm; text-align:center;">CÓDIGO</th>
					<th style="width: 1.5cm; text-align:center;">OTROS CÓDIGOS</th>
					<th style="width: 1cm; text-align:center;">CÓDIGO ARPRO</th>
					<th style="width: 1.5cm; text-align:center;">GRUPO CONTABLE</th>
					<th style="width: 1.5cm; text-align:center;">AUXILIAR</th>
					<th style="width: 4cm; text-align:center;">DESCRIPCIÓN SENAPE</th>
					<th style="width: 4cm; text-align:center;">DESCRIPCIÓN ARPRO</th>
					<th style="width: 4cm; text-align:center;">UBICACIÓN</th>
					<th style="width: 2cm; text-align:center;">RESPONSABLE</th>
					<th style="width: 1cm; text-align:center;">ESTADO</th>
				</tr>
			</thead>
			<tbody>
				<?php
              $contador = 1;
				?>
				<?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td style="text-align:center;"><?php echo e($contador++); ?></td>
					<td style="text-align:center;"><?php echo e($dato->COD_COMPLETO); ?></td>
					<td style="text-align:center; width: 1.5cm;"><?php echo e($dato->OTROS_CODIGOS); ?></td>
					<td style="text-align:center;"><?php echo e($dato->COD_COMPUESTO); ?></td>
					<td style="text-align:center;"><?php echo e($dato->GRUPO_CONTABLE); ?></td>
					<td style="text-align:center;"><?php echo e($dato->AUXILIAR); ?></td>
					<td><?php echo e($dato->DESCRIP_SENAPE); ?></td>
					<td><?php echo e($dato->DESCRIPCION); ?></td>
					<td style="text-align:center;"><?php echo e('EDIF: '.$dato->EDIFICIO.' PISO: '.$dato->PISO. ' OFICINA: '.$dato->OFICINA. ' - ' . $dato->UBI_ESPEC); ?></td>
					<td style="text-align:center;"><?php echo e($dato->RESPONSABLE); ?></td>
                    <td style="text-align:center;"><?php echo e($dato->ESTADO); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
			<tfoot>
				<tr style="border: 1px solid;" >
					<th style="font-size: x-small; text-align: right;" colspan="11" ><b>Cantidad: </b><?php echo e($total); ?></th>
				</tr>
			</tfoot>
		</table>
		
	</main>
	<script type="text/php">
		if ( isset($pdf) ) {
			$pdf->page_script('
				$font = $fontMetrics->get_font("Arial, Helvetica, sans-serif", "NORMAL");
				$pdf->text(850, 20, "$PAGE_NUM de $PAGE_COUNT", $font, 7);
			');
		}
	</script>
</body>
</html><?php /**PATH C:\laragon\www\senape\resources\views/plantillapdf/repVerificados.blade.php ENDPATH**/ ?>