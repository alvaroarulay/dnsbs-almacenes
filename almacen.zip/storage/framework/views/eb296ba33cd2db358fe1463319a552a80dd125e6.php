

<html>
<head>
	<style>
	@page {
		margin: 0cm 0cm;
	}
	body{
		font-family: 'arial', sans-serif;
		margin-top: 3.5cm;
		margin-left: 1.5cm;
		margin-right: 1.5cm;
		margin-bottom: 2cm;
		width: 29.5cm;
	}
	hr{
		margin: 0;
		border-top: 1px solid rgb(0, 0, 0);
	}
	#customers {
		border-collapse: collapse;
		font-size: 7pt;
	}
	#customers td, #customers th {
		padding: 5px;
		border: 1px solid #000;
	}
	#customers th {
		text-align: left;
		background-color: #ddd;
		color: black;
	}
	#customers thead { display: table-header-group; }
	.eslogan{
		font-size: xx-small;
		font-style: italic;
	}
	#cabecera tr td{
		margin:0;
		padding:0;
		font-size: 6pt;
	}
	header {
		position: fixed;
		top: 1cm;
		left: 1cm;
		right: 1cm;
		height: 3cm;
		}
	footer {
		position: fixed;
		bottom: 0cm;
		left: 1.5cm;
		right: 0cm;
		height: 2cm;
	}
	.page-break {
	    page-break-after: always;
	}
</style>
</head>
<body>
	<header>
		<div style="width: 33cm; height: 2.2cm;">
		<table>
			<tr>
				<td>
					<div style="width: 4cm; height: 2.5cm; text-align: center;">
						<img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="" style="width: auto; height: 1.5cm; ">
					</div>
				</td>
				<td>
					<div style="width: 18cm; height: 2cm;">
					<p style="margin-top: 0.5cm; text-align: center;" ><b>BIENES NO VERIFICADOS FÍSICAMENTE - <?php echo e($titulo); ?></b></p>
				
				</div>
				</td>
				<td>
					<div style="width: 4cm; height: 2.5cm; text-align: right; font-size: 6pt;">
						<b>
						<p>
						REVALUOS PROFESIONALES
						</p>
						<p>
							GESTION 2025
						</p>
						<p>
							PRODUCTO Nº 1 - INFORME DE INVENTARIO
						</p>	
						</b>
						
					</div>
					
				</td>
				<td>
					<div style="width: 4cm; height: 2.5cm; text-align: center;">
						<img src="<?php echo e(asset('img/arpro.jpg')); ?>" style="width: auto; height: 2cm; ">
					</div>
				</td>
			</tr>
		</table>
	</div>
	</header>
	<main>
		<table id="customers">
			<thead>
				<tr style="border: 1px solid ;">
					<th style="width: 1cm;">NRO.</th>
					<th style="width: 2cm;">CÓDIGO</th>
					<th style="width: 2cm;">GRUPO CONTABLE</th>
					<th style="width: 8cm;">DESCRIPCIÓN</th>
					<th style="width: 2cm;">CIUDAD</th>
					<th style="width: 5cm;">UBICACIÓN</th>
					<th style="width: 5cm;">RESPONSABLE</th>
					<th style="width: 2.5cm;">ESTADO</th>
				</tr>
			</thead>
			<tbody>
				<?php
              $contador = 1;
				?>
				<?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($contador++); ?></td>
					<td><?php echo e($dato->CODIGO); ?></td>
					<td><?php echo e($dato->GRUPO_CONTABLE); ?></td>
					<td><?php echo e($dato->DESCRIPCION); ?></td>
					<td><?php echo e($dato->nomciudad); ?></td>
					<td><?php echo e('EDIFICIO: '.$dato->nomedif.' PISO: '.$dato->nompiso.' OFICINA:'.$dato->nomofic); ?>

					</td>
					<td><?php echo e($dato->NOMBRE); ?></td>
                    <td><?php if($dato->ESTADO = 1): ?>
						<?php echo e('BUENO'); ?>

						<?php elseif($dato->ESTADO = 2): ?>
						<?php echo e('REGULAR'); ?>

						<?php elseif($dato->ESTADO = 3): ?>
						<?php echo e('MALO'); ?>

						<?php endif; ?>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
			<tfoot>
				<tr style="border: 1px solid;" >
					<th style="font-size: x-small; text-align: right;" colspan="8" ><b>Cantidad: </b><?php echo e($total); ?></th>
				</tr>
			</tfoot>
		</table>
		
	</main>
	<script type="text/php">
		if ( isset($pdf) ) {
			$pdf->page_script('
				$font = $fontMetrics->get_font("Arial, Helvetica, sans-serif", "NORMAL");
				$pdf->text(900, 20, "$PAGE_NUM de $PAGE_COUNT", $font, 7);
			');
		}
	</script>
</body>
</html><?php /**PATH C:\laragon\www\inventory\resources\views/plantillapdf/repFaltantes.blade.php ENDPATH**/ ?>