<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ejemplo Header Fijo</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
			letter-spacing: 1px;
        }
        #cabecera{
            height: 0.8cm;
            margin-top: 0.1cm;
            margin-bottom: 1cm;
            padding: 0;
        }
        #cabecera tr td{
            margin:0;
            padding:0;
        }
		#customers {
            border-collapse: collapse;
            margin-top: 0.2cm;
            font-size: 6pt;
		}
		#customers td {
			padding: 5px;
		}
		#customers th{
			text-align: left;
			background-color: #ddd;
			color: black;
		}
		#customers tfoot tr{
			border: 1px solid black;
		}
    </style>
</head>
<body>
   <main>
         <table id="cabecera">
			<tr style=" height: .5cm;">
				<td >
					<p style="font-size: xx-small; margin: 0.1cm; text-align: right;"><b>ALMACEN:</b></p>
				</td>
				<td style=" height: .5cm; width:7cm;">
					<p style="font-size: xx-small; margin: 0.1cm;"><?php echo e($almacen); ?></p>
				</td>
			</tr>
			<tr style=" height: .5cm;">
				<td >
				<p style="font-size: xx-small; margin: 0.1cm; text-align: right;"><b>ESTABLECIMIENTO:</b></p>
				</td>
				<td >
				<p style="font-size: xx-small; margin: 0.1cm;"><?php echo e($establecimiento); ?></p>
				</td>
			</tr>
        </table>
        <table id="customers">
            <thead>
                <tr style="border: 1px solid ;">
                    <th style="width: 1cm;">NRO.</th>
                    <th style="width: 2cm;">CÓDIGO ANTERIOR</th>
                    <th style="width: 2cm;">CÓDIGO</th>
					<th style="width: 8cm;">DESCRIPCIÓN</th>
					<th style="width: 3cm;">UNIDAD</th>
					<th style="width: 5cm;">PARTIDA</th>
				  	<th style="width: 4cm;">ALMACEN</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($dato->cod_anterior); ?></td>
                        <td><?php echo e($dato->codigo); ?></td>
						<td><?php echo e($dato->descripcion); ?></td>
						<td><?php echo e($dato->unidad); ?></td>	
						<td><?php echo e($dato->partida); ?></td>
						<td><?php echo e($dato->almacen); ?></td>
                    </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
				<tr style="border: 1px solid;" >
					<th style="font-size: xx-small; text-align: right;" colspan="7" ><b>Cantidad: </b><?php echo e($datos->count()); ?></th>
				</tr>
			</tfoot>
        </table>
    </main>

</body>
</html>
<?php /**PATH C:\laragon\www\almacenes\resources\views/plantillapdf/main.blade.php ENDPATH**/ ?>